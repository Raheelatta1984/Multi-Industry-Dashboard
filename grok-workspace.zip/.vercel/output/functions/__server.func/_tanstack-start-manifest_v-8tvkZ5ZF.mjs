//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-8tvkZ5ZF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/catalog",
			"/data",
			"/fx",
			"/board/$id"
		],
		preloads: ["/assets/index-B0RGW66H.js", "/assets/dist-BO-UtobA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B0RGW66H.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-arD8oVwj.js",
			"/assets/selectors-TgDVtnPI.js",
			"/assets/widgets-CnDlns4n.js",
			"/assets/badge-Ch1I2kIx.js",
			"/assets/card-9cj4tGSk.js"
		]
	},
	"/catalog": {
		filePath: "/workspace/src/routes/catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/catalog-R5aKcXco.js",
			"/assets/badge-Ch1I2kIx.js",
			"/assets/card-9cj4tGSk.js",
			"/assets/input-C3rEjH06.js"
		]
	},
	"/data": {
		filePath: "/workspace/src/routes/data.tsx",
		children: void 0,
		preloads: [
			"/assets/data-DVRH03vS.js",
			"/assets/selectors-TgDVtnPI.js",
			"/assets/badge-Ch1I2kIx.js",
			"/assets/card-9cj4tGSk.js"
		]
	},
	"/fx": {
		filePath: "/workspace/src/routes/fx.tsx",
		children: void 0,
		preloads: [
			"/assets/fx-D5eUO-ct.js",
			"/assets/selectors-TgDVtnPI.js",
			"/assets/charts-Dy7PEIUC.js",
			"/assets/card-9cj4tGSk.js",
			"/assets/input-C3rEjH06.js"
		]
	},
	"/board/$id": {
		filePath: "/workspace/src/routes/board.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/board._id-Pu7VNntN.js",
			"/assets/widgets-CnDlns4n.js",
			"/assets/badge-Ch1I2kIx.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
