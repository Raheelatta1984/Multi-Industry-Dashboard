import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useAppStore } from "./router-CvEkSbUt.mjs";
import { d as formatMonth, f as formatNumber, u as formatMoney } from "./selectors-MiIHOkmM.mjs";
import { a as YAxis, c as Line, d as Pie, f as Cell, h as Legend, i as LineChart, l as CartesianGrid, m as Tooltip, n as PieChart, o as XAxis, p as ResponsiveContainer, r as BarChart, s as Area, t as AreaChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/charts-BJjtjZ3C.js
var import_jsx_runtime = require_jsx_runtime();
var GRID = "color-mix(in oklab, var(--color-foreground) 6%, transparent)";
var TICK = "var(--color-muted-foreground)";
var COLORS = [
	"var(--color-chart-1)",
	"var(--color-chart-2)",
	"var(--color-chart-3)",
	"var(--color-chart-4)",
	"var(--color-chart-5)",
	"var(--color-silver)",
	"var(--color-up)",
	"var(--color-warn)"
];
function ChartTip({ active, payload, label, money = true }) {
	const ccy = useAppStore((s) => s.displayCurrency);
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-popover px-3 py-2 text-xs shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-1 text-muted-foreground",
			children: label ? formatMonth(label.length === 7 ? `${label}-01` : label) : ""
		}), payload.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-6 tabular",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: p.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: money ? formatMoney(p.value, ccy, { compact: true }) : formatNumber(p.value, true) })]
		}, p.name))]
	});
}
function DualArea({ data, aKey, bKey, aName, bName }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: GRID,
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "period",
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatMonth(String(v).length === 7 ? `${v}-01` : String(v)),
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatNumber(Number(v), true),
					axisLine: false,
					tickLine: false,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: aKey,
					name: aName,
					stroke: "var(--color-chart-1)",
					fill: "var(--color-chart-1)",
					fillOpacity: .18,
					strokeWidth: 1.6
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: bKey,
					name: bName,
					stroke: "var(--color-chart-2)",
					fill: "var(--color-chart-2)",
					fillOpacity: .1,
					strokeWidth: 1.6
				})
			]
		})
	});
}
function SimpleBar({ data, money = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: GRID,
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "name",
					tick: {
						fill: TICK,
						fontSize: 11
					},
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatNumber(Number(v), true),
					axisLine: false,
					tickLine: false,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, { money }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: "value",
					name: "Value",
					radius: [
						6,
						6,
						0,
						0
					],
					fill: "var(--color-chart-1)",
					maxBarSize: 36
				})
			]
		})
	});
}
function SimpleDonut({ data }) {
	const ccy = useAppStore((s) => s.displayCurrency);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
				data,
				dataKey: "value",
				nameKey: "name",
				innerRadius: "58%",
				outerRadius: "82%",
				paddingAngle: 2,
				stroke: "none",
				children: data.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: COLORS[i % COLORS.length] }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
				formatter: (v) => formatMoney(Number(v), ccy, { compact: true }),
				contentStyle: {
					background: "var(--color-popover)",
					border: "1px solid var(--color-border)",
					borderRadius: 8,
					color: "var(--color-popover-foreground)"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
				verticalAlign: "bottom",
				height: 36,
				formatter: (v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: v
				})
			})
		] })
	});
}
function StackedSpend({ data }) {
	const keys = data.length ? Object.keys(data[0]).filter((k) => k !== "period") : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: GRID,
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "period",
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatMonth(String(v).length === 7 ? `${v}-01` : String(v)),
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatNumber(Number(v), true),
					axisLine: false,
					tickLine: false,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
				keys.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: k,
					stackId: "a",
					fill: COLORS[i % COLORS.length],
					maxBarSize: 28
				}, k))
			]
		})
	});
}
function ForecastLines({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: GRID,
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "period",
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatMonth(String(v).length === 7 ? `${v}-01` : String(v)),
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatNumber(Number(v), true),
					axisLine: false,
					tickLine: false,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: "actual",
					name: "Actual",
					stroke: "var(--color-chart-1)",
					strokeWidth: 1.8,
					dot: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: "expected",
					name: "Expected",
					stroke: "var(--color-chart-2)",
					strokeWidth: 1.8,
					dot: false,
					strokeDasharray: "4 4"
				})
			]
		})
	});
}
function DemandLines({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
			data,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: GRID,
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "period",
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatMonth(String(v).length === 7 ? `${v}-01` : String(v)),
					axisLine: false,
					tickLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					tick: {
						fill: TICK,
						fontSize: 11
					},
					tickFormatter: (v) => formatNumber(Number(v), true),
					axisLine: false,
					tickLine: false,
					width: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, { money: false }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: "avg",
					name: "Average",
					stroke: "var(--color-chart-4)",
					strokeWidth: 1.6,
					dot: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: "norm",
					name: "Norm",
					stroke: "var(--color-chart-3)",
					strokeWidth: 1.6,
					dot: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
					type: "monotone",
					dataKey: "expected",
					name: "Expected",
					stroke: "var(--color-chart-1)",
					strokeWidth: 2,
					dot: false
				})
			]
		})
	});
}
//#endregion
export { SimpleDonut as a, SimpleBar as i, DualArea as n, StackedSpend as o, ForecastLines as r, DemandLines as t };
