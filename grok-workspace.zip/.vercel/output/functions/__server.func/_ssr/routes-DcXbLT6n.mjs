import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { l as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { _ as INDUSTRIES, a as useAppStore, d as DASHBOARDS, f as DASHBOARD_COUNT, i as Button } from "./router-CvEkSbUt.mjs";
import { S as upcomingRows, h as kpisFor, p as formatPct, u as formatMoney } from "./selectors-MiIHOkmM.mjs";
import { t as Badge } from "./badge-B0bSb0m1.mjs";
import { t as Card } from "./card-iUfGZlHj.mjs";
import { t as DashboardCanvas } from "./widgets-CwTlNA6j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DcXbLT6n.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const wb = useAppStore((s) => s.workbook);
	const ccy = useAppStore((s) => s.displayCurrency);
	const rates = new Map(wb.fx.map((r) => [r.currency, r.rateToUsd]));
	const kpis = kpisFor(wb, {
		industry: "all",
		department: "group"
	}, ccy, rates);
	const board = DASHBOARDS.find((d) => d.id === "group-command");
	const due = upcomingRows(wb, {
		industry: "all",
		department: "group"
	}, ccy, rates).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-7xl flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stagger-in flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.18em] text-silver uppercase",
							children: "Apex Meridian Group"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-4xl leading-tight lg:text-5xl",
							children: "Every number. Every department. One live surface."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 max-w-xl text-sm text-muted-foreground",
							children: [DASHBOARD_COUNT, " boards across twelve industries. Fill the Excel template, inject it, and only new or changed rows patch in — history stays still. Currency conversion is live."]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/data",
							children: "Inject Excel"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/catalog",
							children: "Browse boards"
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					kpis.revenue,
					kpis.opex,
					kpis.forecast,
					kpis.upcoming
				].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground uppercase",
							children: k.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 font-display text-2xl tabular lg:text-3xl",
							children: formatMoney(k.value, ccy, { compact: true })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `mt-1 text-xs tabular ${k.delta >= 0 ? "text-up" : "text-down"}`,
							children: formatPct(k.delta)
						})
					]
				}, k.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardCanvas, { board }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Divisions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "silver",
							children: INDUSTRIES.length
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-border",
						children: INDUSTRIES.map((ind) => {
							const sliceK = kpisFor(wb, {
								industry: ind.id,
								department: "group"
							}, ccy, rates);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm",
									children: ind.division
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: ind.label
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular text-sm",
										children: formatMoney(sliceK.revenue.value, ccy, { compact: true })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/board/$id",
										params: { id: `${ind.id}-executive` },
										className: "rounded-md p-2 text-muted-foreground hover:bg-secondary hover:text-foreground",
										"aria-label": `Open ${ind.label} command`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
									})]
								})]
							}, ind.id);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Due next"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/board/$id",
								params: { id: "group-upcoming" },
								children: "All upcoming"
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-3",
						children: due.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-xl bg-secondary/40 px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm",
								children: u.description
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground",
								children: [
									u.dueDate,
									" · ",
									u.industry
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "tabular text-sm",
								children: formatMoney(u.converted, ccy, { compact: true })
							})]
						}, u.id))
					})]
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
