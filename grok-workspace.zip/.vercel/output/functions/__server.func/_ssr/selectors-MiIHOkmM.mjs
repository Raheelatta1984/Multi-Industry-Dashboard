import { g as FX_TO_USD } from "./router-CvEkSbUt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/selectors-MiIHOkmM.js
function formatMoney(amount, currency, opts) {
	const compact = opts?.compact ?? Math.abs(amount) >= 1e4;
	const digits = opts?.digits;
	try {
		return new Intl.NumberFormat("en-US", {
			style: "currency",
			currency,
			notation: compact ? "compact" : "standard",
			maximumFractionDigits: digits ?? (compact ? 1 : 0),
			minimumFractionDigits: compact ? 0 : digits ?? 0
		}).format(amount);
	} catch {
		const code = currency || "USD";
		return `${compact ? new Intl.NumberFormat("en-US", {
			notation: "compact",
			maximumFractionDigits: 1
		}).format(amount) : new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(amount)} ${code}`;
	}
}
function formatNumber(n, compact = false) {
	return new Intl.NumberFormat("en-US", {
		notation: compact && Math.abs(n) >= 1e4 ? "compact" : "standard",
		maximumFractionDigits: compact ? 1 : 0
	}).format(n);
}
function formatPct(n, digits = 1) {
	return `${n > 0 ? "+" : ""}${(n * 100).toFixed(digits)}%`;
}
function formatDate(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return new Intl.DateTimeFormat("en-GB", {
		day: "2-digit",
		month: "short",
		year: "numeric",
		timeZone: "UTC"
	}).format(d);
}
function formatMonth(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return new Intl.DateTimeFormat("en-GB", {
		month: "short",
		year: "2-digit",
		timeZone: "UTC"
	}).format(d);
}
function relativeTime(ts, now = Date.now()) {
	const s = Math.max(0, Math.round((now - ts) / 1e3));
	if (s < 5) return "just now";
	if (s < 60) return `${s}s ago`;
	const m = Math.round(s / 60);
	if (m < 60) return `${m}m ago`;
	return `${Math.round(m / 60)}h ago`;
}
function fxMap(rows) {
	const map = /* @__PURE__ */ new Map();
	for (const row of rows) map.set(row.currency, row.rateToUsd);
	if (!map.has("USD")) map.set("USD", 1);
	return map;
}
function convertAmount(amount, from, to, rates) {
	if (!Number.isFinite(amount)) return 0;
	if (from === to) return amount;
	const fromUsd = rates.get(from) ?? FX_TO_USD[from] ?? 1;
	const toUsd = rates.get(to) ?? FX_TO_USD[to] ?? 1;
	if (!toUsd) return amount * fromUsd;
	return amount * fromUsd / toUsd;
}
function inSlice(row, slice) {
	if (slice.industry && slice.industry !== "all" && row.industry && row.industry !== slice.industry) return false;
	if (slice.department && slice.department !== "group" && row.department && row.department !== slice.department) return false;
	return true;
}
function monthKey(iso) {
	return iso.slice(0, 7);
}
var YTD_START = "2026-01-01";
var PREV_YTD_START = "2025-01-01";
var PREV_YTD_END = "2025-08-31";
var YTD_END = "2026-08-31";
function toDisplay(amount, from, display, rates) {
	return convertAmount(amount, from, display, rates);
}
function revenueSeries(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.revenue) {
		if (!inSlice(row, slice)) continue;
		const k = monthKey(row.date);
		map.set(k, (map.get(k) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	return [...map.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([period, value]) => ({
		period,
		value
	}));
}
function opexSeries(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.expenses) {
		if (!inSlice(row, slice)) continue;
		const k = monthKey(row.date);
		map.set(k, (map.get(k) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	return [...map.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([period, value]) => ({
		period,
		value
	}));
}
function sumRange(rows, slice, display, rates, start, end, amountFn = (r) => r.amount ?? 0) {
	let s = 0;
	for (const row of rows) {
		if (!inSlice(row, slice)) continue;
		const d = row.date ?? row.period ?? "";
		if (d < start || d > end) continue;
		s += toDisplay(amountFn(row), row.currency, display, rates);
	}
	return s;
}
function kpisFor(wb, slice, display, rates) {
	const revYtd = sumRange(wb.revenue, slice, display, rates, YTD_START, YTD_END);
	const revPrev = sumRange(wb.revenue, slice, display, rates, PREV_YTD_START, PREV_YTD_END);
	const opexYtd = sumRange(wb.expenses, slice, display, rates, YTD_START, YTD_END);
	const opexPrev = sumRange(wb.expenses, slice, display, rates, PREV_YTD_START, PREV_YTD_END);
	const contribution = revYtd - opexYtd;
	const margin = revYtd ? contribution / revYtd : 0;
	const prevMargin = revPrev ? (revPrev - opexPrev) / revPrev : 0;
	const revSpark = revenueSeries(wb, slice, display, rates).map((d) => d.value);
	const opexSpark = opexSeries(wb, slice, display, rates).map((d) => d.value);
	let book = 0;
	let gross = 0;
	for (const a of wb.assets) {
		if (!inSlice(a, slice)) continue;
		if (a.status === "disposed") continue;
		book += toDisplay(a.bookValue, a.currency, display, rates);
		gross += toDisplay(a.cost, a.currency, display, rates);
	}
	let license = 0;
	let seats = 0;
	let expiring = 0;
	for (const l of wb.licenses) {
		if (!inSlice(l, slice)) continue;
		const annual = l.cycle === "monthly" ? l.unitCost * l.seats * 12 : l.unitCost * l.seats;
		license += toDisplay(annual, l.currency, display, rates);
		seats += l.seats;
		if (l.end >= "2026-08-31" && l.end <= "2026-11-30") expiring += 1;
	}
	let upcoming = 0;
	for (const u of wb.upcoming) {
		if (!inSlice(u, slice)) continue;
		if (u.status === "paid") continue;
		if (u.dueDate > "2026-11-30") continue;
		upcoming += toDisplay(u.amount, u.currency, display, rates);
	}
	let forecast = 0;
	for (const f of wb.forecast) {
		if (!inSlice(f, slice)) continue;
		if (f.period > "2026-11-30") continue;
		forecast += toDisplay(f.expectedAmount, f.currency, display, rates);
	}
	let demandAmt = 0;
	let demandUnits = 0;
	let normUnits = 0;
	for (const d of wb.demand) {
		if (slice.industry && slice.industry !== "all" && d.industry !== slice.industry) continue;
		if (d.period > "2026-11-30") continue;
		demandUnits += d.expectedUnits;
		normUnits += d.normUnits;
		const sale = wb.sales.find((s) => s.sku === d.sku && s.industry === d.industry);
		const px = sale?.unitPrice ?? 0;
		const ccy = sale?.currency ?? display;
		demandAmt += toDisplay(d.expectedUnits * px, ccy, display, rates);
	}
	let units = 0;
	let salesValue = 0;
	for (const s of wb.sales) {
		if (!inSlice(s, slice)) continue;
		if (s.date < YTD_START || s.date > YTD_END) continue;
		units += s.units;
		salesValue += toDisplay(s.units * s.unitPrice, s.currency, display, rates);
	}
	const asp = units ? salesValue / units : 0;
	let cogs = 0;
	let inv = 0;
	let tCount = 0;
	for (const t of wb.turnover) {
		if (!inSlice(t, slice)) continue;
		if (t.period < YTD_START) continue;
		cogs += toDisplay(t.cogs, t.currency, display, rates);
		inv += toDisplay((t.inventoryStart + t.inventoryEnd) / 2, t.currency, display, rates);
		tCount += 1;
	}
	const turnover = inv ? cogs / (inv / Math.max(1, tCount)) : 0;
	let exposure = 0;
	const byCcy = /* @__PURE__ */ new Map();
	for (const r of wb.revenue) {
		if (!inSlice(r, slice)) continue;
		if (r.date < YTD_START) continue;
		if (r.currency === display) continue;
		const v = toDisplay(r.amount, r.currency, display, rates);
		exposure += v;
		byCcy.set(r.currency, (byCcy.get(r.currency) ?? 0) + v);
	}
	const lastRev = revSpark[revSpark.length - 1] ?? 0;
	const prevRev = revSpark[revSpark.length - 2] ?? lastRev;
	const lastOpex = opexSpark[opexSpark.length - 1] ?? 0;
	const prevOpex = opexSpark[opexSpark.length - 2] ?? lastOpex;
	const actualLast = lastRev;
	const fcMonth = wb.forecast.filter((f) => inSlice(f, slice) && f.period.startsWith("2026-08")).reduce((s, f) => s + toDisplay(f.expectedAmount, f.currency, display, rates), 0);
	const accuracy = fcMonth ? 1 - Math.min(1, Math.abs(actualLast - fcMonth) / fcMonth) : .92;
	return {
		revenue: {
			key: "revenue",
			label: "Revenue YTD",
			value: revYtd,
			delta: revPrev ? (revYtd - revPrev) / revPrev : lastRev && prevRev ? (lastRev - prevRev) / prevRev : 0,
			spark: revSpark,
			format: "money"
		},
		opex: {
			key: "opex",
			label: "Expenditure YTD",
			value: opexYtd,
			delta: opexPrev ? (opexYtd - opexPrev) / opexPrev : lastOpex && prevOpex ? (lastOpex - prevOpex) / prevOpex : 0,
			spark: opexSpark,
			format: "money"
		},
		contribution: {
			key: "contribution",
			label: "Contribution",
			value: contribution,
			delta: margin - prevMargin,
			spark: revSpark.map((v, i) => v - (opexSpark[i] ?? 0)),
			format: "money"
		},
		margin: {
			key: "margin",
			label: "Margin",
			value: margin,
			delta: margin - prevMargin,
			spark: revSpark.map((v, i) => v ? (v - (opexSpark[i] ?? 0)) / v : 0),
			format: "pct"
		},
		assets: {
			key: "assets",
			label: "Gross assets",
			value: gross,
			delta: gross ? (book - gross) / gross : 0,
			spark: [
				gross * .7,
				gross * .78,
				gross * .86,
				book
			],
			format: "money"
		},
		bookValue: {
			key: "bookValue",
			label: "Book value",
			value: book,
			delta: gross ? (book - gross) / gross : 0,
			spark: [
				book * .92,
				book * .95,
				book * .98,
				book
			],
			format: "money"
		},
		licenses: {
			key: "licenses",
			label: "License run-rate",
			value: license,
			delta: .03,
			spark: [
				license * .9,
				license * .94,
				license * .98,
				license
			],
			format: "money"
		},
		seats: {
			key: "seats",
			label: "Seats",
			value: seats,
			delta: .02,
			spark: [
				seats * .9,
				seats * .94,
				seats * .97,
				seats
			],
			format: "number"
		},
		expiring: {
			key: "expiring",
			label: "Expiring 90d",
			value: expiring,
			delta: 0,
			spark: [expiring],
			format: "number"
		},
		upcoming: {
			key: "upcoming",
			label: "Upcoming 90d",
			value: upcoming,
			delta: .04,
			spark: [
				upcoming * .7,
				upcoming * .85,
				upcoming
			],
			format: "money"
		},
		forecast: {
			key: "forecast",
			label: "Expected sales 90d",
			value: forecast,
			delta: revYtd ? forecast / (revYtd / 8) - 1 : 0,
			spark: [
				forecast * .9,
				forecast * .96,
				forecast
			],
			format: "money"
		},
		demand: {
			key: "demand",
			label: "Expected demand",
			value: demandAmt,
			delta: normUnits ? demandUnits / normUnits - 1 : 0,
			spark: [
				demandAmt * .88,
				demandAmt * .94,
				demandAmt
			],
			format: "money"
		},
		turnover: {
			key: "turnover",
			label: "Turnover",
			value: turnover,
			delta: .05,
			spark: [
				turnover * .9,
				turnover * .95,
				turnover
			],
			format: "x"
		},
		units: {
			key: "units",
			label: "Units YTD",
			value: units,
			delta: .06,
			spark: revSpark,
			format: "number"
		},
		asp: {
			key: "asp",
			label: "Average price",
			value: asp,
			delta: .01,
			spark: [
				asp * .97,
				asp * .99,
				asp
			],
			format: "money"
		},
		yoy: {
			key: "yoy",
			label: "vs prior period",
			value: revPrev ? (revYtd - revPrev) / revPrev : 0,
			delta: 0,
			spark: revSpark,
			format: "pct"
		},
		accuracy: {
			key: "accuracy",
			label: "Forecast accuracy",
			value: accuracy,
			delta: .01,
			spark: [
				.86,
				.89,
				accuracy
			],
			format: "pct"
		},
		fxExposure: {
			key: "fxExposure",
			label: "FX exposure",
			value: exposure,
			delta: .002,
			spark: [
				exposure * .96,
				exposure * .99,
				exposure
			],
			format: "money"
		}
	};
}
function regionBars(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.revenue) {
		if (!inSlice(row, slice)) continue;
		if (row.date < YTD_START) continue;
		map.set(row.region, (map.get(row.region) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value
	}));
}
function channelMix(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.revenue) {
		if (!inSlice(row, slice)) continue;
		if (row.date < YTD_START) continue;
		map.set(row.channel, (map.get(row.channel) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value
	}));
}
function expenseStack(wb, slice, display, rates) {
	const months = /* @__PURE__ */ new Map();
	for (const row of wb.expenses) {
		if (!inSlice(row, slice)) continue;
		const m = monthKey(row.date);
		const rec = months.get(m) ?? { period: 0 };
		const cat = row.category;
		rec[cat] = (rec[cat] ?? 0) + toDisplay(row.amount, row.currency, display, rates);
		months.set(m, rec);
	}
	return [...months.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([period, cats]) => ({
		period,
		...cats
	}));
}
function departmentShare(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.expenses) {
		if (slice.industry && slice.industry !== "all" && row.industry !== slice.industry) continue;
		if (row.date < YTD_START) continue;
		map.set(row.department, (map.get(row.department) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value
	}));
}
function vendorBars(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.licenses) {
		if (!inSlice(row, slice)) continue;
		const annual = row.cycle === "monthly" ? row.unitCost * row.seats * 12 : row.unitCost * row.seats;
		map.set(row.vendor, (map.get(row.vendor) ?? 0) + toDisplay(annual, row.currency, display, rates));
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value
	})).sort((a, b) => b.value - a.value).slice(0, 8);
}
function currencyExposure(wb, slice, display, rates) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.revenue) {
		if (!inSlice(row, slice)) continue;
		if (row.date < YTD_START) continue;
		map.set(row.currency, (map.get(row.currency) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value
	}));
}
function forecastCompare(wb, slice, display, rates) {
	const actual = /* @__PURE__ */ new Map();
	for (const row of wb.revenue) {
		if (!inSlice(row, slice)) continue;
		const k = monthKey(row.date);
		actual.set(k, (actual.get(k) ?? 0) + toDisplay(row.amount, row.currency, display, rates));
	}
	const expected = /* @__PURE__ */ new Map();
	for (const row of wb.forecast) {
		if (!inSlice(row, slice)) continue;
		const k = monthKey(row.period);
		expected.set(k, (expected.get(k) ?? 0) + toDisplay(row.expectedAmount, row.currency, display, rates));
	}
	return [.../* @__PURE__ */ new Set([...actual.keys(), ...expected.keys()])].sort().slice(-12).map((period) => ({
		period,
		actual: actual.get(period) ?? 0,
		expected: expected.get(period) ?? 0
	}));
}
function demandCompare(wb, slice) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.demand) {
		if (slice.industry && slice.industry !== "all" && row.industry !== slice.industry) continue;
		const k = monthKey(row.period);
		const rec = map.get(k) ?? {
			avg: 0,
			norm: 0,
			expected: 0,
			safety: 0
		};
		rec.avg += row.avgUnits;
		rec.norm += row.normUnits;
		rec.expected += row.expectedUnits;
		rec.safety += row.safetyStock;
		map.set(k, rec);
	}
	return [...map.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([period, v]) => ({
		period,
		...v
	}));
}
function skuDemand(wb, slice) {
	const map = /* @__PURE__ */ new Map();
	for (const row of wb.demand) {
		if (slice.industry && slice.industry !== "all" && row.industry !== slice.industry) continue;
		map.set(row.sku, (map.get(row.sku) ?? 0) + row.safetyStock);
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value
	})).sort((a, b) => b.value - a.value).slice(0, 8);
}
function upcomingRows(wb, slice, display, rates) {
	return wb.upcoming.filter((u) => inSlice(u, slice) && u.status !== "paid").sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 12).map((u) => ({
		...u,
		converted: toDisplay(u.amount, u.currency, display, rates)
	}));
}
function licenseRows(wb, slice, display, rates) {
	return wb.licenses.filter((l) => inSlice(l, slice)).map((l) => {
		const annual = l.cycle === "monthly" ? l.unitCost * l.seats * 12 : l.unitCost * l.seats;
		return {
			...l,
			annual: toDisplay(annual, l.currency, display, rates)
		};
	}).sort((a, b) => b.annual - a.annual).slice(0, 12);
}
function assetRows(wb, slice, display, rates) {
	return wb.assets.filter((a) => inSlice(a, slice)).map((a) => ({
		...a,
		costC: toDisplay(a.cost, a.currency, display, rates),
		bookC: toDisplay(a.bookValue, a.currency, display, rates)
	})).sort((a, b) => b.bookC - a.bookC).slice(0, 12);
}
function workbookStats(wb) {
	return {
		revenue: wb.revenue.length,
		expenses: wb.expenses.length,
		sales: wb.sales.length,
		assets: wb.assets.length,
		licenses: wb.licenses.length,
		upcoming: wb.upcoming.length,
		forecast: wb.forecast.length,
		demand: wb.demand.length,
		turnover: wb.turnover.length,
		departments: wb.departments.length,
		fx: wb.fx.length
	};
}
//#endregion
export { vendorBars as C, upcomingRows as S, opexSeries as _, demandCompare as a, revenueSeries as b, forecastCompare as c, formatMonth as d, formatNumber as f, licenseRows as g, kpisFor as h, currencyExposure as i, formatDate as l, fxMap as m, channelMix as n, departmentShare as o, formatPct as p, convertAmount as r, expenseStack as s, assetRows as t, formatMoney as u, regionBars as v, workbookStats as w, skuDemand as x, relativeTime as y };
