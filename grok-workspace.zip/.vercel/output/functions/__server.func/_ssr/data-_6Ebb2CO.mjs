import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useAppStore, c as parseWorkbook, i as Button, l as workbookToXlsx, o as blankTemplateWorkbook, r as Switch, s as downloadArrayBuffer, u as generateSampleWorkbook } from "./router-CvEkSbUt.mjs";
import { m as fxMap, u as formatMoney, w as workbookStats, y as relativeTime } from "./selectors-MiIHOkmM.mjs";
import { t as Badge } from "./badge-B0bSb0m1.mjs";
import { t as Card } from "./card-iUfGZlHj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-_6Ebb2CO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DataPage() {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	const loadWorkbook = useAppStore((s) => s.loadWorkbook);
	const resetSample = useAppStore((s) => s.resetSample);
	const mergeUploads = useAppStore((s) => s.mergeUploads);
	const setMergeUploads = useAppStore((s) => s.setMergeUploads);
	const wb = useAppStore((s) => s.workbook);
	const fileName = useAppStore((s) => s.fileName);
	const source = useAppStore((s) => s.source);
	const issues = useAppStore((s) => s.issues);
	const reports = useAppStore((s) => s.reports);
	const last = useAppStore((s) => s.lastReport);
	const ccy = useAppStore((s) => s.displayCurrency);
	const stats = workbookStats(wb);
	async function onFile(file) {
		setBusy(true);
		setMessage(null);
		try {
			const buf = await file.arrayBuffer();
			const parsed = parseWorkbook(buf);
			const report = loadWorkbook(parsed.workbook, file.name, parsed.issues);
			setMessage(`Patched ${file.name}: +${report.added} new, ~${report.updated} updated, ${report.skipped} unchanged.`);
		} catch (err) {
			setMessage(err instanceof Error ? err.message : "Could not read that workbook.");
		} finally {
			setBusy(false);
		}
	}
	function downloadSample() {
		const buf = workbookToXlsx(generateSampleWorkbook());
		downloadArrayBuffer(buf, "meridian-sample.xlsx");
	}
	function downloadTemplate() {
		const buf = workbookToXlsx(blankTemplateWorkbook());
		downloadArrayBuffer(buf, "meridian-template.xlsx");
	}
	function downloadConverted() {
		const buf = workbookToXlsx(wb, {
			currency: ccy,
			rates: fxMap(wb.fx)
		});
		downloadArrayBuffer(buf, `meridian-${ccy.toLowerCase()}.xlsx`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-5xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.16em] text-silver uppercase",
					children: "Data studio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl lg:text-4xl",
					children: "Inject Excel. Patch only what changed."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Download the filled sample or a short template, edit amounts in Excel, then drop the file here. Matching ids update in place. New ids append. Unchanged history is not rewritten."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border p-10 text-center",
				onClick: () => inputRef.current?.click(),
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault();
					const file = e.dataTransfer.files[0];
					if (file) onFile(file);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-2xl",
						children: "Drop .xlsx here"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md text-sm text-muted-foreground",
						children: "Sheets: Meta, FX, Departments, Revenue, Expenses, Assets, Licenses, Upcoming, Sales, Forecast, Demand, Turnover."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy,
						children: busy ? "Reading…" : "Choose file"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						type: "file",
						accept: ".xlsx,.xls,.csv",
						className: "hidden",
						onChange: (e) => {
							const file = e.target.files?.[0];
							if (file) onFile(file);
							e.target.value = "";
						}
					})
				]
			}),
			message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-silver",
				children: message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: downloadSample,
						children: "Download sample"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: downloadTemplate,
						children: "Download template"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: downloadConverted,
						children: ["Export in ", ccy]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => resetSample(),
						children: "Reset sample"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "ml-auto flex items-center gap-2 text-sm text-muted-foreground",
						children: ["Merge on upload", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: mergeUploads,
							onCheckedChange: setMergeUploads
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: Object.entries(stats).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground uppercase",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 font-display text-2xl tabular",
						children: v
					})]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Active workbook"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: source === "sample" ? "silver" : "up",
							children: source
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [fileName, last ? ` · last patch ${relativeTime(last.at)} · ${last.latencyMs}ms` : null]
					}),
					issues.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1 text-sm text-warn",
						children: issues.map((i, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							i.sheet,
							": ",
							i.message
						] }, idx))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Incremental log"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Each minute the live feed mutates a thin slice of recent rows. Older months are skipped on purpose."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 divide-y divide-border",
						children: [reports.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-3 text-sm text-muted-foreground",
							children: "No patches yet."
						}), reports.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"+",
								r.added,
								" added · ~",
								r.updated,
								" updated · -",
								r.removed,
								" removed · ",
								r.skipped,
								" unchanged"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular text-muted-foreground",
								children: [
									r.latencyMs,
									"ms · ",
									relativeTime(r.at)
								]
							})]
						}, r.at))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Column contract"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [
							"Keep a unique ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "id"
							}),
							" per row. Amounts stay in source currency; conversion happens on the board and in the ",
							ccy,
							" export. Forecast method may be",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "norm"
							}),
							", ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "average"
							}),
							", or",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: "blend"
							}),
							" (0.55 trailing average + 0.45 seasonal norm)."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: "Current display total revenue YTD is a converted figure — change currency in the header to reprice every widget without touching history."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 tabular text-sm",
						children: [
							"Sample converted snapshot: ",
							formatMoney(wb.revenue.slice(0, 1)[0]?.amount ?? 0, ccy, { compact: true }),
							" on first revenue row."
						]
					})
				]
			})
		]
	});
}
//#endregion
export { DataPage as component };
