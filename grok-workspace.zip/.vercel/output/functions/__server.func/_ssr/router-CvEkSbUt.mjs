import { i as __toESM } from "../_runtime.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime, n as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as RefreshCw, c as Database, i as Search, n as Upload, o as Menu, r as TriangleAlert, s as LayoutGrid, t as X } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { i as writeSync, n as readSync, r as utils, t as SSF } from "../_libs/xlsx.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle$1, r as DialogContent$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as _e } from "../_libs/cmdk.mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { i as Viewport, n as Scrollbar, r as Thumb, t as Root } from "../_libs/radix-ui__react-scroll-area.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cn-DCjuAqpA.js
var INDUSTRIES = [
	{
		id: "retail",
		label: "Retail",
		short: "Retail",
		division: "Apex Retail"
	},
	{
		id: "wholesale",
		label: "Wholesale",
		short: "Wholesale",
		division: "Apex Wholesale"
	},
	{
		id: "manufacturing",
		label: "Manufacturing",
		short: "Mfg",
		division: "Meridian Works"
	},
	{
		id: "healthcare",
		label: "Healthcare",
		short: "Health",
		division: "Meridian Health"
	},
	{
		id: "hospitality",
		label: "Hospitality",
		short: "Hospitality",
		division: "Harbor Stays"
	},
	{
		id: "logistics",
		label: "Logistics",
		short: "Logistics",
		division: "Northline Logistics"
	},
	{
		id: "financial",
		label: "Financial Services",
		short: "Finance",
		division: "Meridian Capital"
	},
	{
		id: "technology",
		label: "Technology",
		short: "Tech",
		division: "Lumen Software"
	},
	{
		id: "energy",
		label: "Energy",
		short: "Energy",
		division: "Volt Energy"
	},
	{
		id: "education",
		label: "Education",
		short: "Education",
		division: "Meridian Academy"
	},
	{
		id: "realestate",
		label: "Real Estate",
		short: "Property",
		division: "Parcel & Place"
	},
	{
		id: "cpg",
		label: "Consumer Goods",
		short: "CPG",
		division: "Everyday Goods"
	}
];
var DEPARTMENTS = [
	{
		id: "executive",
		label: "Executive",
		board: "Command",
		ownerTitle: "Managing Director"
	},
	{
		id: "finance",
		label: "Finance",
		board: "P&L and Expenditure",
		ownerTitle: "Finance Controller"
	},
	{
		id: "sales",
		label: "Sales",
		board: "Revenue Pulse",
		ownerTitle: "VP Sales"
	},
	{
		id: "marketing",
		label: "Marketing",
		board: "Growth Spend",
		ownerTitle: "CMO Office"
	},
	{
		id: "operations",
		label: "Operations",
		board: "Run Rate",
		ownerTitle: "COO Office"
	},
	{
		id: "procurement",
		label: "Procurement",
		board: "Vendor Spend",
		ownerTitle: "Head of Procurement"
	},
	{
		id: "assets",
		label: "Assets",
		board: "Register",
		ownerTitle: "Asset Controller"
	},
	{
		id: "licenses",
		label: "IT and Licenses",
		board: "License Cost",
		ownerTitle: "IT Finance"
	},
	{
		id: "treasury",
		label: "Treasury",
		board: "FX and Cash",
		ownerTitle: "Treasurer"
	},
	{
		id: "supply",
		label: "Supply Chain",
		board: "Demand Planning",
		ownerTitle: "Demand Planner"
	},
	{
		id: "hrcost",
		label: "People Cost",
		board: "Workforce Spend",
		ownerTitle: "People Finance"
	},
	{
		id: "floor",
		label: "Frontline",
		board: "Trading Floor",
		ownerTitle: "General Manager"
	}
];
var CURRENCIES = [
	{
		code: "USD",
		name: "US Dollar",
		symbol: "$"
	},
	{
		code: "EUR",
		name: "Euro",
		symbol: "€"
	},
	{
		code: "GBP",
		name: "Pound Sterling",
		symbol: "£"
	},
	{
		code: "JPY",
		name: "Yen",
		symbol: "¥"
	},
	{
		code: "AUD",
		name: "Australian Dollar",
		symbol: "A$"
	},
	{
		code: "CAD",
		name: "Canadian Dollar",
		symbol: "C$"
	},
	{
		code: "CHF",
		name: "Swiss Franc",
		symbol: "CHF"
	},
	{
		code: "CNY",
		name: "Yuan",
		symbol: "¥"
	},
	{
		code: "INR",
		name: "Indian Rupee",
		symbol: "₹"
	},
	{
		code: "SGD",
		name: "Singapore Dollar",
		symbol: "S$"
	},
	{
		code: "AED",
		name: "UAE Dirham",
		symbol: "AED"
	},
	{
		code: "BRL",
		name: "Brazilian Real",
		symbol: "R$"
	}
];
var FX_TO_USD = {
	USD: 1,
	EUR: 1.087,
	GBP: 1.273,
	JPY: .00672,
	AUD: .661,
	CAD: .728,
	CHF: 1.124,
	CNY: .139,
	INR: .0119,
	SGD: .742,
	AED: .272,
	BRL: .181
};
var REGIONS = [
	"AMER",
	"EMEA",
	"APAC",
	"LATAM"
];
var CHANNELS = [
	"Direct",
	"Online",
	"Partner",
	"Wholesale"
];
var EXPENSE_CATEGORIES = [
	"Payroll",
	"Cloud and SaaS",
	"Facilities",
	"Media",
	"Freight",
	"Travel",
	"Professional",
	"Utilities",
	"Maintenance",
	"Insurance"
];
var ASSET_CATEGORIES = [
	"Property",
	"Plant",
	"Fleet",
	"IT Hardware",
	"Fixtures",
	"Medical",
	"Energy"
];
var LICENSE_VENDORS = [
	"Salesforce",
	"Microsoft",
	"SAP",
	"Adobe",
	"ServiceNow",
	"Atlassian",
	"Oracle",
	"AWS",
	"Google Cloud",
	"Workday"
];
/** January-first seasonal index. */
var SEASONALITY = {
	retail: [
		.82,
		.78,
		.88,
		.92,
		.98,
		.95,
		.9,
		.93,
		.97,
		1.05,
		1.28,
		1.55
	],
	wholesale: [
		.9,
		.88,
		.94,
		.98,
		1.02,
		1.04,
		.96,
		.98,
		1.06,
		1.1,
		1.12,
		1.02
	],
	manufacturing: [
		.92,
		.94,
		1.02,
		1.06,
		1.08,
		1.04,
		.9,
		.88,
		1.04,
		1.08,
		1.02,
		.96
	],
	healthcare: [
		1.08,
		1.04,
		1.02,
		.98,
		.96,
		.94,
		.92,
		.94,
		.98,
		1.02,
		1.04,
		1.08
	],
	hospitality: [
		.78,
		.8,
		.92,
		1.04,
		1.12,
		1.28,
		1.35,
		1.3,
		1.08,
		.96,
		.88,
		1.18
	],
	logistics: [
		.88,
		.9,
		.98,
		1.02,
		1.06,
		1.08,
		1.04,
		1.02,
		1.1,
		1.16,
		1.22,
		1.14
	],
	financial: [
		1.06,
		.98,
		1.02,
		1.04,
		1,
		1.02,
		.96,
		.94,
		1.04,
		1.06,
		1.08,
		1.12
	],
	technology: [
		.94,
		.96,
		1.02,
		1.04,
		1.06,
		1.08,
		1.04,
		1.02,
		1.08,
		1.1,
		1.12,
		1.18
	],
	energy: [
		1.22,
		1.18,
		1.06,
		.92,
		.84,
		.8,
		.82,
		.84,
		.9,
		1.02,
		1.14,
		1.26
	],
	education: [
		1.12,
		1.08,
		1.02,
		.88,
		.72,
		.58,
		.52,
		1.18,
		1.28,
		1.16,
		1.08,
		.96
	],
	realestate: [
		.9,
		.92,
		1.04,
		1.1,
		1.12,
		1.08,
		1.04,
		1.02,
		1.06,
		1.08,
		.98,
		.94
	],
	cpg: [
		.86,
		.84,
		.94,
		.98,
		1.02,
		1.06,
		1.08,
		1.04,
		1,
		1.06,
		1.16,
		1.22
	]
};
var BASE_MONTHLY_REVENUE = {
	retail: 42e5,
	wholesale: 61e5,
	manufacturing: 54e5,
	healthcare: 38e5,
	hospitality: 29e5,
	logistics: 32e5,
	financial: 48e5,
	technology: 59e5,
	energy: 72e5,
	education: 18e5,
	realestate: 24e5,
	cpg: 45e5
};
var PRODUCTS = {
	retail: [
		{
			sku: "RTL-110",
			name: "Meridian Tee",
			price: 48
		},
		{
			sku: "RTL-204",
			name: "North Parka",
			price: 220
		},
		{
			sku: "RTL-318",
			name: "Trail Sneaker",
			price: 128
		},
		{
			sku: "RTL-441",
			name: "Studio Bag",
			price: 96
		},
		{
			sku: "RTL-512",
			name: "Harbor Scarf",
			price: 54
		},
		{
			sku: "RTL-670",
			name: "Apex Denim",
			price: 118
		},
		{
			sku: "RTL-808",
			name: "Lumen Watch",
			price: 340
		},
		{
			sku: "RTL-901",
			name: "Floor Cap",
			price: 32
		}
	],
	wholesale: [
		{
			sku: "WHS-12",
			name: "Case Pack A",
			price: 86
		},
		{
			sku: "WHS-18",
			name: "Case Pack B",
			price: 112
		},
		{
			sku: "WHS-24",
			name: "Pallet Mix",
			price: 640
		},
		{
			sku: "WHS-31",
			name: "Private Label",
			price: 44
		},
		{
			sku: "WHS-40",
			name: "Club Bundle",
			price: 210
		},
		{
			sku: "WHS-55",
			name: "Foodservice Crate",
			price: 175
		},
		{
			sku: "WHS-62",
			name: "Impulse Tray",
			price: 28
		},
		{
			sku: "WHS-77",
			name: "Seasonal Crate",
			price: 260
		}
	],
	manufacturing: [
		{
			sku: "MFG-A1",
			name: "Precision Housing",
			price: 420
		},
		{
			sku: "MFG-B4",
			name: "Drive Assembly",
			price: 890
		},
		{
			sku: "MFG-C2",
			name: "Seal Kit",
			price: 64
		},
		{
			sku: "MFG-D9",
			name: "Control Board",
			price: 310
		},
		{
			sku: "MFG-E3",
			name: "Frame Weldment",
			price: 540
		},
		{
			sku: "MFG-F7",
			name: "Bearing Set",
			price: 96
		},
		{
			sku: "MFG-G5",
			name: "Motor 2.2kW",
			price: 760
		},
		{
			sku: "MFG-H8",
			name: "Sensor Pack",
			price: 145
		}
	],
	healthcare: [
		{
			sku: "HLT-OP",
			name: "Outpatient Visit",
			price: 280
		},
		{
			sku: "HLT-DX",
			name: "Diagnostics Panel",
			price: 190
		},
		{
			sku: "HLT-RX",
			name: "Therapy Course",
			price: 640
		},
		{
			sku: "HLT-IM",
			name: "Imaging Slot",
			price: 420
		},
		{
			sku: "HLT-DC",
			name: "Day Case",
			price: 2100
		},
		{
			sku: "HLT-PT",
			name: "Physio Block",
			price: 160
		},
		{
			sku: "HLT-LB",
			name: "Lab Panel",
			price: 88
		},
		{
			sku: "HLT-VC",
			name: "Vaccine Clinic",
			price: 54
		}
	],
	hospitality: [
		{
			sku: "HSP-RN",
			name: "Room Night",
			price: 186
		},
		{
			sku: "HSP-ST",
			name: "Suite Night",
			price: 340
		},
		{
			sku: "HSP-FB",
			name: "F&B Cover",
			price: 48
		},
		{
			sku: "HSP-EV",
			name: "Event Package",
			price: 2400
		},
		{
			sku: "HSP-SP",
			name: "Spa Circuit",
			price: 120
		},
		{
			sku: "HSP-PK",
			name: "Parking Day",
			price: 28
		},
		{
			sku: "HSP-MB",
			name: "Membership",
			price: 90
		},
		{
			sku: "HSP-CT",
			name: "Catering Tray",
			price: 75
		}
	],
	logistics: [
		{
			sku: "LOG-FTL",
			name: "Full Truckload",
			price: 1850
		},
		{
			sku: "LOG-LTL",
			name: "Less-than-load",
			price: 420
		},
		{
			sku: "LOG-PAR",
			name: "Parcel Lane",
			price: 18
		},
		{
			sku: "LOG-AIR",
			name: "Air Freight kg",
			price: 6.4
		},
		{
			sku: "LOG-SEA",
			name: "Ocean TEU",
			price: 2100
		},
		{
			sku: "LOG-WH",
			name: "Warehouse Pallet",
			price: 22
		},
		{
			sku: "LOG-XM",
			name: "Last Mile Stop",
			price: 9.5
		},
		{
			sku: "LOG-CS",
			name: "Cross Dock",
			price: 55
		}
	],
	financial: [
		{
			sku: "FIN-AM",
			name: "AUM Mandate bp",
			price: 42
		},
		{
			sku: "FIN-LN",
			name: "Loan Origination",
			price: 1200
		},
		{
			sku: "FIN-CD",
			name: "Card Interchange",
			price: 18
		},
		{
			sku: "FIN-TR",
			name: "Treasury Desk",
			price: 260
		},
		{
			sku: "FIN-IN",
			name: "Insurance Binder",
			price: 480
		},
		{
			sku: "FIN-AD",
			name: "Advisory Day",
			price: 3200
		},
		{
			sku: "FIN-FX",
			name: "FX Spread Lot",
			price: 75
		},
		{
			sku: "FIN-CS",
			name: "Custody Account",
			price: 35
		}
	],
	technology: [
		{
			sku: "TEC-SE",
			name: "Seat Enterprise",
			price: 68
		},
		{
			sku: "TEC-SB",
			name: "Seat Business",
			price: 32
		},
		{
			sku: "TEC-API",
			name: "API Million",
			price: 14
		},
		{
			sku: "TEC-ST",
			name: "Storage TB",
			price: 22
		},
		{
			sku: "TEC-PS",
			name: "Premium Support",
			price: 1800
		},
		{
			sku: "TEC-IM",
			name: "Implementation",
			price: 12e3
		},
		{
			sku: "TEC-AI",
			name: "Inference Pack",
			price: 240
		},
		{
			sku: "TEC-ED",
			name: "Education Seat",
			price: 9
		}
	],
	energy: [
		{
			sku: "NRG-MWH",
			name: "MWh Retail",
			price: 92
		},
		{
			sku: "NRG-GAS",
			name: "Therm Bundle",
			price: 18
		},
		{
			sku: "NRG-PP",
			name: "PPA Block",
			price: 6400
		},
		{
			sku: "NRG-EV",
			name: "Charge Session",
			price: 11
		},
		{
			sku: "NRG-GR",
			name: "Grid Services",
			price: 420
		},
		{
			sku: "NRG-SOL",
			name: "Solar kW",
			price: 1.4
		},
		{
			sku: "NRG-ST",
			name: "Storage Cycle",
			price: 28
		},
		{
			sku: "NRG-OM",
			name: "O&M Contract",
			price: 2100
		}
	],
	education: [
		{
			sku: "EDU-TU",
			name: "Tuition Term",
			price: 4200
		},
		{
			sku: "EDU-HO",
			name: "Housing Term",
			price: 1800
		},
		{
			sku: "EDU-ON",
			name: "Online Course",
			price: 240
		},
		{
			sku: "EDU-LB",
			name: "Lab Fee",
			price: 180
		},
		{
			sku: "EDU-CF",
			name: "Conference",
			price: 640
		},
		{
			sku: "EDU-RS",
			name: "Research Grant Day",
			price: 1100
		},
		{
			sku: "EDU-CT",
			name: "Catering",
			price: 16
		},
		{
			sku: "EDU-BK",
			name: "Bookstore",
			price: 42
		}
	],
	realestate: [
		{
			sku: "REA-LS",
			name: "Lease Month",
			price: 3200
		},
		{
			sku: "REA-MG",
			name: "Management Fee",
			price: 420
		},
		{
			sku: "REA-PK",
			name: "Parking Stall",
			price: 85
		},
		{
			sku: "REA-FT",
			name: "Fit-out Recovery",
			price: 1800
		},
		{
			sku: "REA-RT",
			name: "Retail Pad",
			price: 5400
		},
		{
			sku: "REA-SV",
			name: "Service Charge",
			price: 210
		},
		{
			sku: "REA-EV",
			name: "Event Hire",
			price: 960
		},
		{
			sku: "REA-ST",
			name: "Storage Cage",
			price: 64
		}
	],
	cpg: [
		{
			sku: "CPG-CL",
			name: "Cleaner 750ml",
			price: 4.2
		},
		{
			sku: "CPG-SN",
			name: "Snack Case",
			price: 18
		},
		{
			sku: "CPG-BV",
			name: "Beverage Pack",
			price: 9.6
		},
		{
			sku: "CPG-PC",
			name: "Personal Care",
			price: 6.4
		},
		{
			sku: "CPG-HM",
			name: "Home Care",
			price: 7.8
		},
		{
			sku: "CPG-BT",
			name: "Beauty SKU",
			price: 14
		},
		{
			sku: "CPG-PB",
			name: "Private Brand",
			price: 5.1
		},
		{
			sku: "CPG-PR",
			name: "Promo Shipper",
			price: 36
		}
	]
};
var COMPANY = {
	name: "Apex Meridian Group",
	fiscalYearStart: "2026-01-01",
	baseCurrency: "USD",
	timezone: "Australia/Sydney"
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CvEkSbUt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function layoutFor(dept) {
	switch (dept) {
		case "executive": return [
			{
				id: "k-rev",
				kind: "kpi",
				title: "Revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-opex",
				kind: "kpi",
				title: "Expenditure",
				metric: "opex",
				span: 4
			},
			{
				id: "k-margin",
				kind: "kpi",
				title: "Contribution margin",
				metric: "margin",
				span: 4
			},
			{
				id: "k-fc",
				kind: "kpi",
				title: "Expected sales",
				metric: "forecast",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Upcoming 90d",
				metric: "upcoming",
				span: 4
			},
			{
				id: "k-lic",
				kind: "kpi",
				title: "License run-rate",
				metric: "licenses",
				span: 4
			},
			{
				id: "c-trend",
				kind: "area",
				title: "Revenue vs expenditure",
				metric: "revenue",
				span: 8,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Revenue by region",
				metric: "revenue",
				span: 4,
				height: "lg"
			},
			{
				id: "t-up",
				kind: "upcoming",
				title: "Commitments due",
				metric: "upcoming",
				span: 6,
				height: "md"
			},
			{
				id: "t-act",
				kind: "activity",
				title: "Incremental feed",
				span: 6,
				height: "md"
			}
		];
		case "finance": return [
			{
				id: "k-opex",
				kind: "kpi",
				title: "YTD expenditure",
				metric: "opex",
				span: 4
			},
			{
				id: "k-rev",
				kind: "kpi",
				title: "YTD revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-cont",
				kind: "kpi",
				title: "Contribution",
				metric: "contribution",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Upcoming expenses",
				metric: "upcoming",
				span: 4
			},
			{
				id: "k-ast",
				kind: "kpi",
				title: "Asset book",
				metric: "assets",
				span: 4
			},
			{
				id: "k-lic",
				kind: "kpi",
				title: "License cost",
				metric: "licenses",
				span: 4
			},
			{
				id: "c-stack",
				kind: "stack",
				title: "Spend mix by category",
				metric: "opex",
				span: 8,
				height: "lg"
			},
			{
				id: "c-donut",
				kind: "donut",
				title: "Department share",
				metric: "opex",
				span: 4,
				height: "lg"
			},
			{
				id: "t-up",
				kind: "upcoming",
				title: "Expenditure calendar",
				metric: "upcoming",
				span: 12,
				height: "md"
			}
		];
		case "sales": return [
			{
				id: "k-rev",
				kind: "kpi",
				title: "Revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-units",
				kind: "kpi",
				title: "Units",
				metric: "units",
				span: 4
			},
			{
				id: "k-asp",
				kind: "kpi",
				title: "Average price",
				metric: "asp",
				span: 4
			},
			{
				id: "k-fc",
				kind: "kpi",
				title: "Expected future sales",
				metric: "forecast",
				span: 4
			},
			{
				id: "k-acc",
				kind: "kpi",
				title: "Forecast accuracy",
				metric: "accuracy",
				span: 4
			},
			{
				id: "k-yoy",
				kind: "kpi",
				title: "Run-rate vs prior",
				metric: "yoy",
				span: 4
			},
			{
				id: "c-area",
				kind: "area",
				title: "Trading trend",
				metric: "revenue",
				span: 8,
				height: "lg"
			},
			{
				id: "c-donut",
				kind: "donut",
				title: "Channel mix",
				metric: "revenue",
				span: 4,
				height: "lg"
			},
			{
				id: "c-fc",
				kind: "forecast",
				title: "Actual vs expected vs norm",
				metric: "forecast",
				span: 12,
				height: "lg"
			}
		];
		case "marketing": return [
			{
				id: "k-opex",
				kind: "kpi",
				title: "Growth spend",
				metric: "opex",
				span: 4
			},
			{
				id: "k-rev",
				kind: "kpi",
				title: "Attributed revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Booked campaigns",
				metric: "upcoming",
				span: 4
			},
			{
				id: "k-margin",
				kind: "kpi",
				title: "Efficiency",
				metric: "margin",
				span: 4
			},
			{
				id: "c-area",
				kind: "area",
				title: "Spend against revenue",
				metric: "opex",
				span: 8,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Channel contribution",
				metric: "revenue",
				span: 4,
				height: "lg"
			},
			{
				id: "c-stack",
				kind: "stack",
				title: "Category spend",
				metric: "opex",
				span: 12,
				height: "md"
			}
		];
		case "operations": return [
			{
				id: "k-trn",
				kind: "kpi",
				title: "Inventory turnover",
				metric: "turnover",
				span: 4
			},
			{
				id: "k-dem",
				kind: "kpi",
				title: "Expected demand",
				metric: "demand",
				span: 4
			},
			{
				id: "k-opex",
				kind: "kpi",
				title: "Run cost",
				metric: "opex",
				span: 4
			},
			{
				id: "k-rev",
				kind: "kpi",
				title: "Throughput value",
				metric: "revenue",
				span: 4
			},
			{
				id: "c-area",
				kind: "area",
				title: "Turnover and COGS",
				metric: "turnover",
				span: 8,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Region throughput",
				metric: "revenue",
				span: 4,
				height: "lg"
			},
			{
				id: "c-dem",
				kind: "demand",
				title: "Demand vs average vs norm",
				metric: "demand",
				span: 12,
				height: "lg"
			}
		];
		case "procurement": return [
			{
				id: "k-opex",
				kind: "kpi",
				title: "Vendor spend",
				metric: "opex",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Open commitments",
				metric: "upcoming",
				span: 4
			},
			{
				id: "k-lic",
				kind: "kpi",
				title: "Contracted licenses",
				metric: "licenses",
				span: 4
			},
			{
				id: "k-ast",
				kind: "kpi",
				title: "Capital purchases",
				metric: "assets",
				span: 4
			},
			{
				id: "c-stack",
				kind: "stack",
				title: "Spend by category",
				metric: "opex",
				span: 8,
				height: "lg"
			},
			{
				id: "c-donut",
				kind: "donut",
				title: "Vendor concentration",
				metric: "opex",
				span: 4,
				height: "lg"
			},
			{
				id: "t-up",
				kind: "upcoming",
				title: "Purchase calendar",
				metric: "upcoming",
				span: 12,
				height: "md"
			}
		];
		case "assets": return [
			{
				id: "k-book",
				kind: "kpi",
				title: "Book value",
				metric: "bookValue",
				span: 4
			},
			{
				id: "k-ast",
				kind: "kpi",
				title: "Gross cost",
				metric: "assets",
				span: 4
			},
			{
				id: "k-opex",
				kind: "kpi",
				title: "Holding cost",
				metric: "opex",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Capex upcoming",
				metric: "upcoming",
				span: 4
			},
			{
				id: "c-donut",
				kind: "donut",
				title: "Category mix",
				metric: "assets",
				span: 4,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Book value by industry slice",
				metric: "assets",
				span: 8,
				height: "lg"
			},
			{
				id: "t-ast",
				kind: "assets",
				title: "Asset register",
				metric: "assets",
				span: 12,
				height: "lg"
			}
		];
		case "licenses": return [
			{
				id: "k-lic",
				kind: "kpi",
				title: "Annualized license cost",
				metric: "licenses",
				span: 4
			},
			{
				id: "k-seats",
				kind: "kpi",
				title: "Seats",
				metric: "seats",
				span: 4
			},
			{
				id: "k-exp",
				kind: "kpi",
				title: "Expiring 90d",
				metric: "expiring",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Renewal cash",
				metric: "upcoming",
				span: 4
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Cost by vendor",
				metric: "licenses",
				span: 8,
				height: "lg"
			},
			{
				id: "c-donut",
				kind: "donut",
				title: "Cycle mix",
				metric: "licenses",
				span: 4,
				height: "lg"
			},
			{
				id: "t-lic",
				kind: "licenses",
				title: "License book",
				metric: "licenses",
				span: 12,
				height: "lg"
			}
		];
		case "treasury": return [
			{
				id: "k-fx",
				kind: "kpi",
				title: "FX exposure",
				metric: "fxExposure",
				span: 4
			},
			{
				id: "k-rev",
				kind: "kpi",
				title: "Converted revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-opex",
				kind: "kpi",
				title: "Converted opex",
				metric: "opex",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Settlements due",
				metric: "upcoming",
				span: 4
			},
			{
				id: "c-fx",
				kind: "fx",
				title: "Rates and conversion",
				metric: "fxExposure",
				span: 6,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Exposure by currency",
				metric: "fxExposure",
				span: 6,
				height: "lg"
			},
			{
				id: "c-area",
				kind: "area",
				title: "Converted P&L",
				metric: "revenue",
				span: 12,
				height: "md"
			}
		];
		case "supply": return [
			{
				id: "k-dem",
				kind: "kpi",
				title: "Expected demand",
				metric: "demand",
				span: 4
			},
			{
				id: "k-fc",
				kind: "kpi",
				title: "Expected sales",
				metric: "forecast",
				span: 4
			},
			{
				id: "k-trn",
				kind: "kpi",
				title: "Turnover",
				metric: "turnover",
				span: 4
			},
			{
				id: "k-units",
				kind: "kpi",
				title: "Units moved",
				metric: "units",
				span: 4
			},
			{
				id: "c-dem",
				kind: "demand",
				title: "Norms vs average vs expected",
				metric: "demand",
				span: 8,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Safety stock by SKU",
				metric: "demand",
				span: 4,
				height: "lg"
			},
			{
				id: "c-fc",
				kind: "forecast",
				title: "Forward sales",
				metric: "forecast",
				span: 12,
				height: "md"
			}
		];
		case "hrcost": return [
			{
				id: "k-opex",
				kind: "kpi",
				title: "People cost",
				metric: "opex",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Payroll upcoming",
				metric: "upcoming",
				span: 4
			},
			{
				id: "k-lic",
				kind: "kpi",
				title: "HR systems",
				metric: "licenses",
				span: 4
			},
			{
				id: "k-yoy",
				kind: "kpi",
				title: "Cost trajectory",
				metric: "yoy",
				span: 4
			},
			{
				id: "c-stack",
				kind: "stack",
				title: "Cost composition",
				metric: "opex",
				span: 8,
				height: "lg"
			},
			{
				id: "c-area",
				kind: "area",
				title: "Monthly people spend",
				metric: "opex",
				span: 4,
				height: "lg"
			},
			{
				id: "t-up",
				kind: "upcoming",
				title: "Payroll and benefits calendar",
				metric: "upcoming",
				span: 12,
				height: "md"
			}
		];
		case "floor": return [
			{
				id: "k-rev",
				kind: "kpi",
				title: "Frontline revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-units",
				kind: "kpi",
				title: "Units",
				metric: "units",
				span: 4
			},
			{
				id: "k-asp",
				kind: "kpi",
				title: "Average ticket",
				metric: "asp",
				span: 4
			},
			{
				id: "k-fc",
				kind: "kpi",
				title: "Expected take",
				metric: "forecast",
				span: 4
			},
			{
				id: "c-area",
				kind: "area",
				title: "Trading pulse",
				metric: "revenue",
				span: 8,
				height: "lg"
			},
			{
				id: "c-bar",
				kind: "bar",
				title: "Region mix",
				metric: "revenue",
				span: 4,
				height: "lg"
			},
			{
				id: "c-donut",
				kind: "donut",
				title: "Channel",
				metric: "revenue",
				span: 4,
				height: "md"
			},
			{
				id: "c-fc",
				kind: "forecast",
				title: "Demand-led forecast",
				metric: "forecast",
				span: 8,
				height: "md"
			}
		];
		case "group": return [
			{
				id: "k-rev",
				kind: "kpi",
				title: "Group revenue",
				metric: "revenue",
				span: 4
			},
			{
				id: "k-opex",
				kind: "kpi",
				title: "Group expenditure",
				metric: "opex",
				span: 4
			},
			{
				id: "k-margin",
				kind: "kpi",
				title: "Margin",
				metric: "margin",
				span: 4
			},
			{
				id: "k-fc",
				kind: "kpi",
				title: "Expected sales",
				metric: "forecast",
				span: 4
			},
			{
				id: "k-dem",
				kind: "kpi",
				title: "Expected demand",
				metric: "demand",
				span: 4
			},
			{
				id: "k-up",
				kind: "kpi",
				title: "Upcoming",
				metric: "upcoming",
				span: 4
			},
			{
				id: "c-heat",
				kind: "heatmap",
				title: "Department map",
				span: 12,
				height: "lg"
			},
			{
				id: "c-area",
				kind: "area",
				title: "Consolidated trend",
				metric: "revenue",
				span: 8,
				height: "md"
			},
			{
				id: "t-act",
				kind: "activity",
				title: "Live patches",
				span: 4,
				height: "md"
			}
		];
	}
}
var GROUP_BOARDS = [
	{
		id: "group-command",
		title: "Group Command",
		eyebrow: "Apex Meridian",
		description: "Live holding-company pulse across every industry and department.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-revenue",
		title: "Group Revenue",
		eyebrow: "Turnover",
		description: "Consolidated revenue, units, and average selling price.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-expenditure",
		title: "Group Expenditure",
		eyebrow: "Cost",
		description: "Operating spend, vendors, and upcoming cash.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-assets",
		title: "Group Assets",
		eyebrow: "Register",
		description: "Book value, gross cost, and idle assets across divisions.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-licenses",
		title: "Group License Cost",
		eyebrow: "SaaS",
		description: "Annualized software cost, seats, and renewals.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-upcoming",
		title: "Upcoming Expenses",
		eyebrow: "90-day cash",
		description: "Committed and scheduled outflows by type and department.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-forecast",
		title: "Expected Future Sales",
		eyebrow: "Forward",
		description: "Blend of seasonal norms and trailing average sales.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-demand",
		title: "Expected Demand",
		eyebrow: "Planning",
		description: "Demand vs norms vs average, with safety stock.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-turnover",
		title: "Inventory Turnover",
		eyebrow: "Working capital",
		description: "COGS against average inventory by industry.",
		industry: "all",
		department: "group"
	},
	{
		id: "group-fx",
		title: "Multi-currency Conversion",
		eyebrow: "Treasury",
		description: "FX rates, exposure, and converted ledgers.",
		industry: "all",
		department: "group"
	}
];
var GROUP_LAYOUT = {
	"group-command": "group",
	"group-revenue": "sales",
	"group-expenditure": "finance",
	"group-assets": "assets",
	"group-licenses": "licenses",
	"group-upcoming": "finance",
	"group-forecast": "sales",
	"group-demand": "supply",
	"group-turnover": "operations",
	"group-fx": "treasury"
};
function industryBoards() {
	const boards = [];
	for (const ind of INDUSTRIES) for (const dept of DEPARTMENTS) boards.push({
		id: `${ind.id}-${dept.id}`,
		title: `${ind.label} ${dept.board}`,
		eyebrow: ind.division,
		description: `${dept.label} view for ${ind.division}, sliced from the live workbook.`,
		industry: ind.id,
		department: dept.id,
		widgets: layoutFor(dept.id)
	});
	return boards;
}
var DASHBOARDS = [...GROUP_BOARDS.map((b) => ({
	...b,
	widgets: layoutFor(GROUP_LAYOUT[b.id] ?? "group")
})), ...industryBoards()];
var DASHBOARD_COUNT = DASHBOARDS.length;
function dashboardById(id) {
	return DASHBOARDS.find((d) => d.id === id);
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function isoDay(year, monthIndex, day = 1) {
	return new Date(Date.UTC(year, monthIndex, day)).toISOString().slice(0, 10);
}
function monthList(start, count) {
	const out = [];
	for (let i = 0; i < count; i++) out.push(isoDay(start.getUTCFullYear(), start.getUTCMonth() + i, 1));
	return out;
}
function jitter(rng, n, p = .1) {
	return n * (1 + (rng() * 2 - 1) * p);
}
function pick$1(rng, arr) {
	return arr[Math.floor(rng() * arr.length)];
}
function monthIndex(iso) {
	return new Date(iso).getUTCMonth();
}
var DEPT_OPEX_SHARE = {
	executive: .04,
	finance: .06,
	sales: .14,
	marketing: .11,
	operations: .16,
	procurement: .08,
	assets: .05,
	licenses: .07,
	treasury: .03,
	supply: .09,
	hrcost: .12,
	floor: .05
};
var INDUSTRY_CCY = {
	retail: "USD",
	wholesale: "USD",
	manufacturing: "EUR",
	healthcare: "GBP",
	hospitality: "AUD",
	logistics: "USD",
	financial: "CHF",
	technology: "USD",
	energy: "EUR",
	education: "GBP",
	realestate: "SGD",
	cpg: "USD"
};
var SAMPLE_AS_OF = "2026-08-31";
function generateSampleWorkbook(seed = 20260831) {
	const rng = mulberry32(seed);
	const now = `${SAMPLE_AS_OF}T08:00:00.000Z`;
	const months = monthList(new Date(Date.UTC(2025, 2, 1)), 18);
	const future = monthList(new Date(Date.UTC(2026, 8, 1)), 6);
	const meta = [{
		id: "meta",
		company: COMPANY.name,
		industry: "all",
		fiscalYearStart: COMPANY.fiscalYearStart,
		baseCurrency: COMPANY.baseCurrency,
		timezone: COMPANY.timezone,
		updatedAt: now
	}];
	const fx = CURRENCIES.map((c) => ({
		id: `fx-${c.code}`,
		currency: c.code,
		rateToUsd: FX_TO_USD[c.code],
		asOf: SAMPLE_AS_OF,
		updatedAt: now
	}));
	const departments = [];
	for (const ind of INDUSTRIES) for (const dept of DEPARTMENTS) departments.push({
		id: `${ind.id}-${dept.id}`,
		name: `${ind.division} ${dept.label}`,
		industry: ind.id,
		department: dept.id,
		owner: `${dept.ownerTitle}`,
		costCenter: `${ind.short.slice(0, 3).toUpperCase()}-${dept.id.slice(0, 3).toUpperCase()}`,
		updatedAt: now
	});
	const revenue = [];
	const sales = [];
	const expenses = [];
	const assets = [];
	const licenses = [];
	const upcoming = [];
	const forecast = [];
	const demand = [];
	const turnover = [];
	const salesBySkuMonth = /* @__PURE__ */ new Map();
	for (const ind of INDUSTRIES) {
		const ccy = INDUSTRY_CCY[ind.id];
		const products = PRODUCTS[ind.id];
		const seasonal = SEASONALITY[ind.id];
		const base = BASE_MONTHLY_REVENUE[ind.id];
		for (const month of months) {
			const monthRev = jitter(rng, base * (seasonal[monthIndex(month)] ?? 1), .08);
			for (const region of REGIONS) {
				const regionShare = region === "AMER" ? .38 : region === "EMEA" ? .28 : region === "APAC" ? .24 : .1;
				for (const channel of CHANNELS) {
					const chShare = channel === "Direct" ? .34 : channel === "Online" ? .3 : channel === "Partner" ? .2 : .16;
					const amount = monthRev * regionShare * chShare;
					const dept = channel === "Online" || channel === "Direct" ? "floor" : "sales";
					revenue.push({
						id: `rev-${ind.id}-${month}-${region}-${channel}`,
						date: month,
						industry: ind.id,
						department: dept,
						product: `${ind.short} mix`,
						channel,
						region,
						amount: Math.round(amount * 100) / 100,
						currency: ccy,
						updatedAt: now
					});
				}
			}
			for (const product of products) {
				const skuShare = .08 + rng() * .08;
				const units = Math.max(4, Math.round(jitter(rng, monthRev * skuShare / product.price, .15)));
				const key = `${ind.id}|${product.sku}|${month}`;
				salesBySkuMonth.set(key, (salesBySkuMonth.get(key) ?? 0) + units);
				sales.push({
					id: `sal-${ind.id}-${product.sku}-${month}`,
					date: month,
					industry: ind.id,
					department: rng() > .45 ? "sales" : "floor",
					sku: product.sku,
					product: product.name,
					units,
					unitPrice: Math.round(jitter(rng, product.price, .04) * 100) / 100,
					currency: ccy,
					region: pick$1(rng, REGIONS),
					channel: pick$1(rng, CHANNELS),
					updatedAt: now
				});
			}
			const monthOpex = monthRev * (.62 + rng() * .1);
			for (const dept of DEPARTMENTS) {
				const share = DEPT_OPEX_SHARE[dept.id];
				const cat = pick$1(rng, EXPENSE_CATEGORIES);
				expenses.push({
					id: `exp-${ind.id}-${dept.id}-${month}`,
					date: month,
					industry: ind.id,
					department: dept.id,
					category: cat,
					vendor: pick$1(rng, LICENSE_VENDORS),
					amount: Math.round(monthOpex * share * 100) / 100,
					currency: ccy,
					recurring: dept.id === "hrcost" || dept.id === "licenses" || rng() > .35,
					updatedAt: now
				});
			}
			const invStart = jitter(rng, monthRev * .45, .1);
			const invEnd = jitter(rng, monthRev * .42, .1);
			const cogs = monthRev * (.46 + rng() * .08);
			turnover.push({
				id: `trn-${ind.id}-${month}`,
				period: month,
				industry: ind.id,
				department: "supply",
				inventoryStart: Math.round(invStart),
				inventoryEnd: Math.round(invEnd),
				cogs: Math.round(cogs),
				currency: ccy,
				updatedAt: now
			});
		}
		for (let a = 0; a < 14; a++) {
			const cost = jitter(rng, 8e4 + a * 4e4, .35);
			const age = rng() * 6;
			assets.push({
				id: `ast-${ind.id}-${a}`,
				name: `${ind.short} ${pick$1(rng, ASSET_CATEGORIES)} ${a + 1}`,
				industry: ind.id,
				department: pick$1(rng, [
					"assets",
					"operations",
					"floor",
					"licenses"
				]),
				category: pick$1(rng, ASSET_CATEGORIES),
				acquired: isoDay(2020 + Math.floor(age), Math.floor(rng() * 12), 1 + Math.floor(rng() * 27)),
				cost: Math.round(cost),
				bookValue: Math.round(cost * (.35 + rng() * .5)),
				currency: ccy,
				status: rng() > .08 ? "active" : rng() > .5 ? "idle" : "disposed",
				updatedAt: now
			});
		}
		for (let l = 0; l < 8; l++) {
			const vendor = LICENSE_VENDORS[l % LICENSE_VENDORS.length];
			const seats = Math.round(jitter(rng, 40 + l * 18, .3));
			const unit = [
				18,
				32,
				48,
				72,
				96,
				120,
				160,
				240
			][l % 8];
			const start = isoDay(2025, l % 12, 1);
			const end = isoDay(2026, (l + 8) % 12, 28);
			licenses.push({
				id: `lic-${ind.id}-${l}`,
				name: `${vendor} ${ind.short}`,
				vendor,
				industry: ind.id,
				department: l % 3 === 0 ? "licenses" : l % 3 === 1 ? "finance" : "sales",
				seats,
				unitCost: unit,
				currency: ccy,
				start,
				end,
				cycle: l % 4 === 0 ? "monthly" : "annual",
				updatedAt: now
			});
		}
		const upcomingTypes = [
			"opex",
			"capex",
			"license",
			"payroll",
			"tax"
		];
		for (let u = 0; u < 10; u++) {
			const due = isoDay(2026, 8 + u % 4, 2 + u * 2);
			upcoming.push({
				id: `upc-${ind.id}-${u}`,
				dueDate: due,
				industry: ind.id,
				department: pick$1(rng, DEPARTMENTS).id,
				description: `${pick$1(rng, EXPENSE_CATEGORIES)} commitment`,
				amount: Math.round(jitter(rng, 18e3 + u * 7500, .4)),
				currency: ccy,
				type: upcomingTypes[u % upcomingTypes.length],
				status: u % 7 === 0 ? "paid" : u % 3 === 0 ? "committed" : "scheduled",
				updatedAt: now
			});
		}
		for (const product of products) {
			const hist = [];
			for (const month of months) hist.push(salesBySkuMonth.get(`${ind.id}|${product.sku}|${month}`) ?? 0);
			const last3 = hist.slice(-3);
			const avg = last3.reduce((s, n) => s + n, 0) / Math.max(1, last3.length);
			const yearlyAvg = hist.reduce((s, n) => s + n, 0) / Math.max(1, hist.length);
			const stdev = Math.sqrt(last3.reduce((s, n) => s + (n - avg) ** 2, 0) / Math.max(1, last3.length));
			for (const period of future) {
				const norm = yearlyAvg * (seasonal[monthIndex(period)] ?? 1);
				const expected = .55 * avg + .45 * norm;
				demand.push({
					id: `dem-${ind.id}-${product.sku}-${period}`,
					period,
					industry: ind.id,
					sku: product.sku,
					avgUnits: Math.round(avg * 10) / 10,
					normUnits: Math.round(norm * 10) / 10,
					expectedUnits: Math.round(expected * 10) / 10,
					safetyStock: Math.round((stdev * 1.65 + avg * .12) * 10) / 10,
					updatedAt: now
				});
				const method = expected > norm ? "average" : expected < avg ? "norm" : "blend";
				forecast.push({
					id: `for-${ind.id}-${product.sku}-${period}`,
					period,
					industry: ind.id,
					department: "sales",
					sku: product.sku,
					expectedUnits: Math.round(expected * 10) / 10,
					expectedAmount: Math.round(expected * product.price * 100) / 100,
					currency: ccy,
					method,
					updatedAt: now
				});
			}
		}
	}
	return {
		meta,
		fx,
		departments,
		revenue,
		expenses,
		assets,
		licenses,
		upcoming,
		sales,
		forecast,
		demand,
		turnover
	};
}
var SAMPLE_SEED = 20260831;
/** Fast non-crypto hash for row fingerprints. */
function cyrb53(str, seed = 0) {
	let h1 = 3735928559 ^ seed;
	let h2 = 1103547991 ^ seed;
	for (let i = 0; i < str.length; i++) {
		const ch = str.charCodeAt(i);
		h1 = Math.imul(h1 ^ ch, 2654435761);
		h2 = Math.imul(h2 ^ ch, 1597334677);
	}
	h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507);
	h1 ^= Math.imul(h2 ^ h2 >>> 13, 3266489909);
	h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507);
	h2 ^= Math.imul(h1 ^ h1 >>> 13, 3266489909);
	return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
function stableSerialize(value) {
	if (value === null || value === void 0) return "";
	if (typeof value !== "object") return String(value);
	if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
	const obj = value;
	return `{${Object.keys(obj).filter((k) => k !== "updatedAt").sort().map((k) => `${k}:${stableSerialize(obj[k])}`).join(",")}}`;
}
function hashRow(row) {
	return cyrb53(stableSerialize(row));
}
var HEADER_ALIASES = {
	amt: "amount",
	amount: "amount",
	value: "amount",
	ccy: "currency",
	curr: "currency",
	currency: "currency",
	dept: "department",
	department: "department",
	department_id: "department",
	industry: "industry",
	date: "date",
	period: "period",
	due: "dueDate",
	due_date: "dueDate",
	duedate: "dueDate",
	updated: "updatedAt",
	updated_at: "updatedAt",
	updatedat: "updatedAt",
	rate: "rateToUsd",
	rate_to_usd: "rateToUsd",
	ratetousd: "rateToUsd",
	as_of: "asOf",
	asof: "asOf",
	unit_cost: "unitCost",
	unitcost: "unitCost",
	unit_price: "unitPrice",
	unitprice: "unitPrice",
	book_value: "bookValue",
	bookvalue: "bookValue",
	expected_units: "expectedUnits",
	expectedunits: "expectedUnits",
	expected_amount: "expectedAmount",
	expectedamount: "expectedAmount",
	avg_units: "avgUnits",
	avgunits: "avgUnits",
	norm_units: "normUnits",
	normunits: "normUnits",
	safety_stock: "safetyStock",
	safetystock: "safetyStock",
	inventory_start: "inventoryStart",
	inventorystart: "inventoryStart",
	inventory_end: "inventoryEnd",
	inventoryend: "inventoryEnd",
	cost_center: "costCenter",
	costcenter: "costCenter",
	fiscal_year_start: "fiscalYearStart",
	fiscalyearstart: "fiscalYearStart",
	base_currency: "baseCurrency",
	basecurrency: "baseCurrency",
	product: "product",
	sku: "sku",
	channel: "channel",
	region: "region",
	category: "category",
	vendor: "vendor",
	name: "name",
	owner: "owner",
	seats: "seats",
	units: "units",
	start: "start",
	end: "end",
	cycle: "cycle",
	status: "status",
	type: "type",
	method: "method",
	recurring: "recurring",
	acquired: "acquired",
	cost: "cost",
	cogs: "cogs",
	company: "company",
	timezone: "timezone",
	description: "description",
	id: "id"
};
function normHeader(h) {
	const raw = String(h ?? "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
	return HEADER_ALIASES[raw] ?? raw;
}
function asString(v, fallback = "") {
	if (v === null || v === void 0) return fallback;
	if (v instanceof Date) return v.toISOString().slice(0, 10);
	if (typeof v === "number" && Number.isFinite(v)) {
		if (v > 2e4 && v < 6e4) {
			const parsed = SSF.parse_date_code(v);
			if (parsed) return new Date(Date.UTC(parsed.y, parsed.m - 1, parsed.d)).toISOString().slice(0, 10);
		}
		return String(v);
	}
	return String(v).trim();
}
function asNumber(v) {
	if (typeof v === "number" && Number.isFinite(v)) return v;
	const n = Number(String(v ?? "").replace(/,/g, ""));
	return Number.isFinite(n) ? n : 0;
}
function asBool(v) {
	const s = String(v ?? "").toLowerCase();
	return s === "true" || s === "1" || s === "yes" || s === "y";
}
function sheetToObjects(wb, names) {
	const name = names.find((n) => wb.SheetNames.some((s) => s.toLowerCase() === n.toLowerCase()));
	if (!name) return [];
	const real = wb.SheetNames.find((s) => s.toLowerCase() === name.toLowerCase());
	const sheet = wb.Sheets[real];
	if (!sheet) return [];
	const rows = utils.sheet_to_json(sheet, {
		header: 1,
		defval: "",
		raw: true
	});
	if (!rows.length) return [];
	const headers = (rows[0] ?? []).map(normHeader);
	const out = [];
	for (let i = 1; i < rows.length; i++) {
		const line = rows[i] ?? [];
		const obj = {};
		let empty = true;
		headers.forEach((h, idx) => {
			if (!h) return;
			const val = line[idx];
			if (val !== "" && val !== null && val !== void 0) empty = false;
			obj[h] = val;
		});
		if (!empty) out.push(obj);
	}
	return out;
}
var CCY = new Set(CURRENCIES.map((c) => c.code));
function ccy(v, fallback = "USD") {
	const s = asString(v, fallback).toUpperCase();
	return CCY.has(s) ? s : fallback;
}
function stamp(v, fallback) {
	return asString(v, fallback) || fallback;
}
function parseWorkbook(buffer) {
	const wb = readSync(buffer, {
		type: "array",
		cellDates: true
	});
	const issues = [];
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const meta = sheetToObjects(wb, ["Meta", "meta"]).map((r, i) => ({
		id: asString(r.id, `meta-${i}`),
		company: asString(r.company, "Uploaded company"),
		industry: asString(r.industry, "all"),
		fiscalYearStart: asString(r.fiscalYearStart, "2026-01-01"),
		baseCurrency: ccy(r.baseCurrency),
		timezone: asString(r.timezone, "UTC"),
		updatedAt: stamp(r.updatedAt, now)
	}));
	if (!meta.length) meta.push({
		id: "meta",
		company: "Uploaded workbook",
		industry: "all",
		fiscalYearStart: "2026-01-01",
		baseCurrency: "USD",
		timezone: "UTC",
		updatedAt: now
	});
	const fx = sheetToObjects(wb, [
		"FX",
		"fx",
		"Rates"
	]).map((r, i) => ({
		id: asString(r.id, `fx-${asString(r.currency, String(i))}`),
		currency: ccy(r.currency),
		rateToUsd: asNumber(r.rateToUsd) || 1,
		asOf: asString(r.asOf, now.slice(0, 10)),
		updatedAt: stamp(r.updatedAt, now)
	}));
	const departments = sheetToObjects(wb, ["Departments", "Department"]).map((r, i) => ({
		id: asString(r.id, `dept-${i}`),
		name: asString(r.name, "Department"),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "finance"),
		owner: asString(r.owner, ""),
		costCenter: asString(r.costCenter, ""),
		updatedAt: stamp(r.updatedAt, now)
	}));
	const revenue = sheetToObjects(wb, ["Revenue"]).map((r, i) => ({
		id: asString(r.id, `rev-${i}`),
		date: asString(r.date, now.slice(0, 10)),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "sales"),
		product: asString(r.product, ""),
		channel: asString(r.channel, "Direct"),
		region: asString(r.region, "AMER"),
		amount: asNumber(r.amount),
		currency: ccy(r.currency),
		updatedAt: stamp(r.updatedAt, now)
	}));
	const expenses = sheetToObjects(wb, ["Expenses", "Expenditure"]).map((r, i) => ({
		id: asString(r.id, `exp-${i}`),
		date: asString(r.date, now.slice(0, 10)),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "finance"),
		category: asString(r.category, "Other"),
		vendor: asString(r.vendor, ""),
		amount: asNumber(r.amount),
		currency: ccy(r.currency),
		recurring: asBool(r.recurring),
		updatedAt: stamp(r.updatedAt, now)
	}));
	const assets = sheetToObjects(wb, ["Assets"]).map((r, i) => ({
		id: asString(r.id, `ast-${i}`),
		name: asString(r.name, `Asset ${i + 1}`),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "assets"),
		category: asString(r.category, "Other"),
		acquired: asString(r.acquired, now.slice(0, 10)),
		cost: asNumber(r.cost),
		bookValue: asNumber(r.bookValue) || asNumber(r.cost),
		currency: ccy(r.currency),
		status: asString(r.status, "active") || "active",
		updatedAt: stamp(r.updatedAt, now)
	}));
	const licenses = sheetToObjects(wb, [
		"Licenses",
		"Licence",
		"Licences"
	]).map((r, i) => ({
		id: asString(r.id, `lic-${i}`),
		name: asString(r.name, `License ${i + 1}`),
		vendor: asString(r.vendor, ""),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "licenses"),
		seats: asNumber(r.seats),
		unitCost: asNumber(r.unitCost),
		currency: ccy(r.currency),
		start: asString(r.start, now.slice(0, 10)),
		end: asString(r.end, now.slice(0, 10)),
		cycle: asString(r.cycle, "annual") === "monthly" ? "monthly" : "annual",
		updatedAt: stamp(r.updatedAt, now)
	}));
	const upcoming = sheetToObjects(wb, ["Upcoming", "UpcomingExpenses"]).map((r, i) => ({
		id: asString(r.id, `upc-${i}`),
		dueDate: asString(r.dueDate, now.slice(0, 10)),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "finance"),
		description: asString(r.description, asString(r.name, "Upcoming")),
		amount: asNumber(r.amount),
		currency: ccy(r.currency),
		type: asString(r.type, "opex") || "opex",
		status: asString(r.status, "scheduled") || "scheduled",
		updatedAt: stamp(r.updatedAt, now)
	}));
	const sales = sheetToObjects(wb, ["Sales"]).map((r, i) => ({
		id: asString(r.id, `sal-${i}`),
		date: asString(r.date, now.slice(0, 10)),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "sales"),
		sku: asString(r.sku, `SKU-${i}`),
		product: asString(r.product, ""),
		units: asNumber(r.units),
		unitPrice: asNumber(r.unitPrice),
		currency: ccy(r.currency),
		region: asString(r.region, "AMER"),
		channel: asString(r.channel, "Direct"),
		updatedAt: stamp(r.updatedAt, now)
	}));
	const forecast = sheetToObjects(wb, ["Forecast"]).map((r, i) => ({
		id: asString(r.id, `for-${i}`),
		period: asString(r.period, asString(r.date, now.slice(0, 10))),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "sales"),
		sku: asString(r.sku, `SKU-${i}`),
		expectedUnits: asNumber(r.expectedUnits),
		expectedAmount: asNumber(r.expectedAmount),
		currency: ccy(r.currency),
		method: asString(r.method, "blend") || "blend",
		updatedAt: stamp(r.updatedAt, now)
	}));
	const demand = sheetToObjects(wb, ["Demand"]).map((r, i) => ({
		id: asString(r.id, `dem-${i}`),
		period: asString(r.period, asString(r.date, now.slice(0, 10))),
		industry: asString(r.industry, "retail"),
		sku: asString(r.sku, `SKU-${i}`),
		avgUnits: asNumber(r.avgUnits),
		normUnits: asNumber(r.normUnits),
		expectedUnits: asNumber(r.expectedUnits),
		safetyStock: asNumber(r.safetyStock),
		updatedAt: stamp(r.updatedAt, now)
	}));
	const turnover = sheetToObjects(wb, ["Turnover"]).map((r, i) => ({
		id: asString(r.id, `trn-${i}`),
		period: asString(r.period, asString(r.date, now.slice(0, 10))),
		industry: asString(r.industry, "retail"),
		department: asString(r.department, "supply"),
		inventoryStart: asNumber(r.inventoryStart),
		inventoryEnd: asNumber(r.inventoryEnd),
		cogs: asNumber(r.cogs),
		currency: ccy(r.currency),
		updatedAt: stamp(r.updatedAt, now)
	}));
	if (!revenue.length && !sales.length && !expenses.length) issues.push({
		sheet: "Workbook",
		row: 0,
		message: "No Revenue, Sales, or Expenses rows found. Check sheet names match the template."
	});
	return {
		workbook: {
			meta,
			fx,
			departments,
			revenue,
			expenses,
			assets,
			licenses,
			upcoming,
			sales,
			forecast,
			demand,
			turnover
		},
		issues
	};
}
function aoa(headers, rows) {
	const data = [headers, ...rows.map((r) => headers.map((h) => r[h] ?? ""))];
	return utils.aoa_to_sheet(data);
}
function workbookToXlsx(data, converted) {
	const book = utils.book_new();
	const conv = converted ? (amount, from) => {
		const fromUsd = converted.rates.get(from) ?? 1;
		const toUsd = converted.rates.get(converted.currency) ?? 1;
		return toUsd ? amount * fromUsd / toUsd : amount;
	} : (amount) => amount;
	const ccyCol = converted?.currency;
	utils.book_append_sheet(book, utils.aoa_to_sheet([
		["Meridian Excel contract"],
		["Fill these sheets, keep column headers, keep unique id values."],
		["Re-upload to merge: only new or changed ids are patched. Unchanged history is left alone."],
		["Amounts may be in any ISO currency listed on FX. Dashboards convert live."],
		["Required sheets: Meta, FX, Revenue or Sales, Expenses. Others optional."],
		["Dates: YYYY-MM-DD. Booleans: true/false. cycle: monthly|annual."],
		["method on Forecast: norm | average | blend (0.55 trailing average + 0.45 seasonal norm)."]
	]), "Instructions");
	utils.book_append_sheet(book, aoa([
		"id",
		"company",
		"industry",
		"fiscalYearStart",
		"baseCurrency",
		"timezone",
		"updatedAt"
	], data.meta), "Meta");
	utils.book_append_sheet(book, aoa([
		"id",
		"currency",
		"rateToUsd",
		"asOf",
		"updatedAt"
	], data.fx), "FX");
	utils.book_append_sheet(book, aoa([
		"id",
		"name",
		"industry",
		"department",
		"owner",
		"costCenter",
		"updatedAt"
	], data.departments), "Departments");
	const moneyHeaders = (extra) => converted ? [
		...extra,
		"amount",
		"currency",
		"amountConverted",
		"displayCurrency",
		"updatedAt"
	] : [
		...extra,
		"amount",
		"currency",
		"updatedAt"
	];
	const withMoney = (rows, extraKeys) => rows.map((r) => ({
		...r,
		amountConverted: converted ? Math.round(conv(r.amount, r.currency) * 100) / 100 : void 0,
		displayCurrency: ccyCol
	}));
	utils.book_append_sheet(book, aoa(moneyHeaders([
		"id",
		"date",
		"industry",
		"department",
		"product",
		"channel",
		"region"
	]), withMoney(data.revenue, [])), "Revenue");
	utils.book_append_sheet(book, aoa(moneyHeaders([
		"id",
		"date",
		"industry",
		"department",
		"category",
		"vendor",
		"recurring"
	]), withMoney(data.expenses, [])), "Expenses");
	utils.book_append_sheet(book, aoa([
		"id",
		"name",
		"industry",
		"department",
		"category",
		"acquired",
		"cost",
		"bookValue",
		"currency",
		"status",
		"updatedAt"
	], data.assets), "Assets");
	utils.book_append_sheet(book, aoa([
		"id",
		"name",
		"vendor",
		"industry",
		"department",
		"seats",
		"unitCost",
		"currency",
		"start",
		"end",
		"cycle",
		"updatedAt"
	], data.licenses), "Licenses");
	utils.book_append_sheet(book, aoa(moneyHeaders([
		"id",
		"dueDate",
		"industry",
		"department",
		"description",
		"type",
		"status"
	]), withMoney(data.upcoming, [])), "Upcoming");
	utils.book_append_sheet(book, aoa([
		"id",
		"date",
		"industry",
		"department",
		"sku",
		"product",
		"units",
		"unitPrice",
		"currency",
		"region",
		"channel",
		"updatedAt"
	], data.sales), "Sales");
	utils.book_append_sheet(book, aoa([
		"id",
		"period",
		"industry",
		"department",
		"sku",
		"expectedUnits",
		"expectedAmount",
		"currency",
		"method",
		"updatedAt"
	], data.forecast), "Forecast");
	utils.book_append_sheet(book, aoa([
		"id",
		"period",
		"industry",
		"sku",
		"avgUnits",
		"normUnits",
		"expectedUnits",
		"safetyStock",
		"updatedAt"
	], data.demand), "Demand");
	utils.book_append_sheet(book, aoa([
		"id",
		"period",
		"industry",
		"department",
		"inventoryStart",
		"inventoryEnd",
		"cogs",
		"currency",
		"updatedAt"
	], data.turnover), "Turnover");
	return writeSync(book, {
		type: "array",
		bookType: "xlsx"
	});
}
function blankTemplateWorkbook() {
	const sample = generateSampleWorkbook();
	const take = (rows, n) => rows.slice(0, n);
	return {
		meta: sample.meta,
		fx: sample.fx,
		departments: take(sample.departments, 12),
		revenue: take(sample.revenue, 8),
		expenses: take(sample.expenses, 8),
		assets: take(sample.assets, 6),
		licenses: take(sample.licenses, 6),
		upcoming: take(sample.upcoming, 6),
		sales: take(sample.sales, 8),
		forecast: take(sample.forecast, 8),
		demand: take(sample.demand, 8),
		turnover: take(sample.turnover, 6)
	};
}
function downloadArrayBuffer(buf, filename) {
	const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var DATA_SHEETS = [
	"meta",
	"fx",
	"departments",
	"revenue",
	"expenses",
	"assets",
	"licenses",
	"upcoming",
	"sales",
	"forecast",
	"demand",
	"turnover"
];
function sheetRows(wb, sheet) {
	return wb[sheet];
}
function diffWorkbooks(prev, next, at = Date.now()) {
	const t0 = typeof performance !== "undefined" ? performance.now() : Date.now();
	const ops = [];
	const sheetsTouched = /* @__PURE__ */ new Set();
	let added = 0;
	let updated = 0;
	let removed = 0;
	let skipped = 0;
	for (const sheet of DATA_SHEETS) {
		const prevRows = sheetRows(prev, sheet);
		const nextRows = sheetRows(next, sheet);
		const prevMap = new Map(prevRows.map((r) => [r.id, r]));
		const nextMap = new Map(nextRows.map((r) => [r.id, r]));
		for (const [id, row] of nextMap) {
			const before = prevMap.get(id);
			if (!before) {
				added += 1;
				sheetsTouched.add(sheet);
				ops.push({
					sheet,
					op: "add",
					id,
					at
				});
				continue;
			}
			if (hashRow(before) === hashRow(row)) {
				skipped += 1;
				continue;
			}
			const fields = Object.keys(row).filter((k) => {
				if (k === "updatedAt") return false;
				return JSON.stringify(before[k]) !== JSON.stringify(row[k]);
			});
			updated += 1;
			sheetsTouched.add(sheet);
			ops.push({
				sheet,
				op: "update",
				id,
				at,
				fields
			});
		}
		for (const id of prevMap.keys()) if (!nextMap.has(id)) {
			removed += 1;
			sheetsTouched.add(sheet);
			ops.push({
				sheet,
				op: "remove",
				id,
				at
			});
		}
	}
	const t1 = typeof performance !== "undefined" ? performance.now() : Date.now();
	return {
		at,
		added,
		updated,
		removed,
		skipped,
		ops,
		latencyMs: Math.round((t1 - t0) * 10) / 10,
		sheetsTouched: [...sheetsTouched]
	};
}
function mergeWorkbooks(base, incoming) {
	const at = Date.now();
	const next = { ...base };
	const ops = [];
	const sheetsTouched = /* @__PURE__ */ new Set();
	let added = 0;
	let updated = 0;
	let removed = 0;
	let skipped = 0;
	for (const sheet of DATA_SHEETS) {
		const current = sheetRows(base, sheet);
		const inc = sheetRows(incoming, sheet);
		if (!inc.length && sheet !== "meta" && sheet !== "fx") {
			next[sheet] = current;
			skipped += current.length;
			continue;
		}
		const index = new Map(current.map((r, i) => [r.id, i]));
		const rows = current.slice();
		for (const row of inc) {
			const i = index.get(row.id);
			if (i === void 0) {
				rows.push(row);
				added += 1;
				sheetsTouched.add(sheet);
				ops.push({
					sheet,
					op: "add",
					id: row.id,
					at
				});
			} else {
				const prev = rows[i];
				if (hashRow(prev) === hashRow(row)) skipped += 1;
				else {
					rows[i] = row;
					updated += 1;
					sheetsTouched.add(sheet);
					ops.push({
						sheet,
						op: "update",
						id: row.id,
						at
					});
				}
			}
		}
		next[sheet] = rows;
	}
	return {
		workbook: next,
		report: {
			at,
			added,
			updated,
			removed,
			skipped,
			ops,
			latencyMs: 0,
			sheetsTouched: [...sheetsTouched]
		}
	};
}
function applyRowMutations(wb, mutations) {
	const next = { ...wb };
	const cloned = /* @__PURE__ */ new Set();
	const ensure = (sheet) => {
		if (!cloned.has(sheet)) {
			next[sheet] = wb[sheet].slice();
			cloned.add(sheet);
		}
		return next[sheet];
	};
	for (const m of mutations) {
		const rows = ensure(m.sheet);
		if (m.op === "add") rows.push(m.row);
		else if (m.op === "remove") {
			const i = rows.findIndex((r) => r.id === m.row.id);
			if (i >= 0) rows.splice(i, 1);
		} else {
			const i = rows.findIndex((r) => r.id === m.row.id);
			if (i >= 0) rows[i] = m.row;
		}
	}
	return next;
}
function pick(rng, arr) {
	return arr[Math.floor(rng() * arr.length)];
}
function simulateTick(wb, seed, atIso) {
	const rng = mulberry32(seed);
	const mutations = [];
	const sales = wb.sales;
	const nUpdate = Math.min(10, Math.max(3, Math.round(sales.length * .004)));
	for (let i = 0; i < nUpdate; i++) {
		const row = sales[Math.floor(rng() * sales.length)];
		if (!row) continue;
		const factor = 1 + (rng() * .03 - .01);
		mutations.push({
			sheet: "sales",
			op: "update",
			row: {
				...row,
				units: Math.max(1, Math.round(row.units * factor)),
				updatedAt: atIso
			}
		});
	}
	const revenue = wb.revenue;
	const nRev = Math.min(8, Math.max(2, Math.round(revenue.length * .003)));
	for (let i = 0; i < nRev; i++) {
		const row = revenue[Math.floor(rng() * revenue.length)];
		if (!row) continue;
		if (row.date < "2026-07-01") continue;
		const factor = 1 + (rng() * .02 - .005);
		mutations.push({
			sheet: "revenue",
			op: "update",
			row: {
				...row,
				amount: Math.round(row.amount * factor * 100) / 100,
				updatedAt: atIso
			}
		});
	}
	const expenses = wb.expenses;
	for (let i = 0; i < 4; i++) {
		const row = expenses[Math.floor(rng() * expenses.length)];
		if (!row) continue;
		if (row.date < "2026-07-01") continue;
		const factor = 1 + (rng() * .025 - .01);
		mutations.push({
			sheet: "expenses",
			op: "update",
			row: {
				...row,
				amount: Math.round(row.amount * factor * 100) / 100,
				updatedAt: atIso
			}
		});
	}
	const industries = Object.keys(PRODUCTS);
	const addCount = 2 + Math.floor(rng() * 4);
	for (let i = 0; i < addCount; i++) {
		const industry = pick(rng, industries);
		const product = pick(rng, PRODUCTS[industry]);
		const row = {
			id: `sal-live-${seed}-${i}`,
			date: atIso.slice(0, 10),
			industry,
			department: rng() > .5 ? "sales" : "floor",
			sku: product.sku,
			product: product.name,
			units: Math.max(1, Math.round(4 + rng() * 40)),
			unitPrice: product.price,
			currency: "USD",
			region: pick(rng, REGIONS),
			channel: pick(rng, CHANNELS),
			updatedAt: atIso
		};
		mutations.push({
			sheet: "sales",
			op: "add",
			row
		});
	}
	const open = wb.upcoming.filter((u) => u.status !== "paid");
	if (open.length && rng() > .55) {
		const row = pick(rng, open);
		mutations.push({
			sheet: "upcoming",
			op: "update",
			row: {
				...row,
				status: rng() > .5 ? "committed" : "paid",
				updatedAt: atIso
			}
		});
	}
	if (rng() > .4) {
		const fxRow = pick(rng, wb.fx);
		if (fxRow.currency !== "USD") {
			const nudged = fxRow.rateToUsd * (1 + (rng() * .003 - .0015));
			mutations.push({
				sheet: "fx",
				op: "update",
				row: {
					...fxRow,
					rateToUsd: Math.round(nudged * 1e6) / 1e6,
					updatedAt: atIso
				}
			});
		}
	}
	const fc = wb.forecast.filter((f) => f.period >= "2026-09-01");
	for (let i = 0; i < 3; i++) {
		const row = fc[Math.floor(rng() * fc.length)];
		if (!row) continue;
		const factor = 1 + (rng() * .02 - .008);
		mutations.push({
			sheet: "forecast",
			op: "update",
			row: {
				...row,
				expectedUnits: Math.round(row.expectedUnits * factor * 10) / 10,
				expectedAmount: Math.round(row.expectedAmount * factor * 100) / 100,
				updatedAt: atIso
			}
		});
	}
	return applyRowMutations(wb, mutations);
}
var TICK_MS = 6e4;
var sampleWorkbook = generateSampleWorkbook(SAMPLE_SEED);
function emptyReport(at = Date.now()) {
	return {
		at,
		added: 0,
		updated: 0,
		removed: 0,
		skipped: 0,
		ops: [],
		latencyMs: 0,
		sheetsTouched: []
	};
}
function rememberCurrency(code) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem("meridian.currency", code);
	} catch {}
}
function readCurrency() {
	if (typeof window === "undefined") return "USD";
	try {
		const v = window.localStorage.getItem("meridian.currency");
		if (v && CURRENCIES.some((c) => c.code === v)) return v;
	} catch {}
	return "USD";
}
var useAppStore = create((set, get) => ({
	workbook: sampleWorkbook,
	source: "sample",
	fileName: "meridian-sample.xlsx",
	displayCurrency: "USD",
	industryFilter: "all",
	liveEnabled: true,
	mergeUploads: true,
	tickCount: 0,
	lastReport: null,
	reports: [],
	issues: [],
	lastTickAt: Date.now(),
	nextTickAt: Date.now() + TICK_MS,
	dirtyUntil: 0,
	company: sampleWorkbook.meta[0]?.company ?? "Apex Meridian Group",
	setCurrency: (code) => {
		rememberCurrency(code);
		set({ displayCurrency: code });
	},
	setIndustry: (id) => set({ industryFilter: id }),
	setLive: (on) => set({
		liveEnabled: on,
		nextTickAt: Date.now() + TICK_MS
	}),
	setMergeUploads: (on) => set({ mergeUploads: on }),
	markDirty: () => set({ dirtyUntil: Date.now() + 900 }),
	tick: () => {
		const state = get();
		const t0 = typeof performance !== "undefined" ? performance.now() : Date.now();
		const iso = (/* @__PURE__ */ new Date()).toISOString();
		const nextWb = simulateTick(state.workbook, SAMPLE_SEED + state.tickCount + 1, iso);
		const report = diffWorkbooks(state.workbook, nextWb, Date.now());
		const t1 = typeof performance !== "undefined" ? performance.now() : Date.now();
		report.latencyMs = Math.round((t1 - t0) * 10) / 10;
		const now = Date.now();
		set({
			workbook: nextWb,
			tickCount: state.tickCount + 1,
			lastReport: report,
			reports: [report, ...state.reports].slice(0, 24),
			lastTickAt: now,
			nextTickAt: now + TICK_MS,
			dirtyUntil: now + 900
		});
		return report;
	},
	loadWorkbook: (wb, fileName, issues) => {
		const state = get();
		const incoming = state.mergeUploads && state.source === "upload" ? mergeWorkbooks(state.workbook, wb) : null;
		const workbook = incoming?.workbook ?? wb;
		const report = incoming?.report ?? diffWorkbooks({
			...sampleWorkbook,
			revenue: [],
			expenses: [],
			sales: []
		}, wb, Date.now());
		const now = Date.now();
		set({
			workbook,
			source: "upload",
			fileName,
			issues,
			lastReport: report,
			reports: [report, ...state.reports].slice(0, 24),
			lastTickAt: now,
			nextTickAt: now + TICK_MS,
			dirtyUntil: now + 1200,
			company: workbook.meta[0]?.company ?? fileName,
			liveEnabled: false
		});
		return report;
	},
	resetSample: () => {
		const now = Date.now();
		set({
			workbook: generateSampleWorkbook(SAMPLE_SEED),
			source: "sample",
			fileName: "meridian-sample.xlsx",
			issues: [],
			lastReport: emptyReport(now),
			reports: [],
			tickCount: 0,
			lastTickAt: now,
			nextTickAt: now + TICK_MS,
			company: sampleWorkbook.meta[0]?.company ?? "Apex Meridian Group",
			liveEnabled: true
		});
	}
}));
var TICK_INTERVAL_MS = TICK_MS;
function hydrateCurrency() {
	const code = readCurrency();
	if (code !== useAppStore.getState().displayCurrency) useAppStore.setState({ displayCurrency: code });
}
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(720px,calc(100vw-1.5rem))] -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-card p-5 text-card-foreground shadow-[var(--shadow-border)]", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 rounded-md p-2 text-muted-foreground hover:bg-secondary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl", className),
		...props
	});
}
function Command$1({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e, {
		className: cn("flex h-full w-full flex-col overflow-hidden rounded-xl bg-popover text-popover-foreground", className),
		...props
	});
}
var CommandInput = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "border-b border-border px-3",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Input, {
		ref,
		className: cn("flex h-12 w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground", className),
		...props
	})
}));
CommandInput.displayName = "CommandInput";
var CommandList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.List, {
	ref,
	className: cn("max-h-80 overflow-y-auto p-1", className),
	...props
}));
CommandList.displayName = "CommandList";
var CommandEmpty = _e.Empty;
function CommandGroup({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Group, {
		className: cn("px-1 py-1.5 text-xs text-muted-foreground", className),
		...props
	});
}
function CommandItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(_e.Item, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-sm text-foreground aria-selected:bg-secondary", className),
		...props
	});
}
function CommandPalette() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				setOpen((v) => !v);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "p-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "sr-only",
				children: "Jump to a board"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: "Search 150+ boards, data, FX…" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No board matches." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandGroup, {
					heading: "Places",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
							onSelect: () => {
								setOpen(false);
								navigate({ to: "/" });
							},
							children: "Command center"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
							onSelect: () => {
								setOpen(false);
								navigate({ to: "/catalog" });
							},
							children: "All boards"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
							onSelect: () => {
								setOpen(false);
								navigate({ to: "/data" });
							},
							children: "Excel data studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
							onSelect: () => {
								setOpen(false);
								navigate({ to: "/fx" });
							},
							children: "Currency conversion"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
					heading: "Boards",
					children: DASHBOARDS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
						value: `${d.title} ${d.eyebrow} ${d.industry} ${d.department}`,
						onSelect: () => {
							setOpen(false);
							navigate({
								to: "/board/$id",
								params: { id: d.id }
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: d.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-xs text-muted-foreground",
							children: d.eyebrow
						})]
					}, d.id))
				})
			] })] })]
		})
	});
}
function LiveEngine() {
	const live = useAppStore((s) => s.liveEnabled);
	const tick = useAppStore((s) => s.tick);
	(0, import_react.useEffect)(() => {
		if (!live) return;
		const first = window.setTimeout(() => tick(), 12e3);
		const id = window.setInterval(() => tick(), TICK_INTERVAL_MS);
		return () => {
			window.clearTimeout(first);
			window.clearInterval(id);
		};
	}, [live, tick]);
	return null;
}
function useCountdown() {
	const next = useAppStore((s) => s.nextTickAt);
	const live = useAppStore((s) => s.liveEnabled);
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(Date.now());
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, []);
	if (!live) return "paused";
	if (now === null) return "1:00";
	const s = Math.max(0, Math.ceil((next - now) / 1e3));
	return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
}
function MeridianMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: cn("size-6 text-foreground", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "24",
				height: "24",
				rx: "6",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "6.2",
				fill: "none",
				className: "stroke-background",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 5.6 L13.15 12 L12 18.4 L10.85 12 Z",
				className: "fill-background"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			outline: "border border-border bg-transparent hover:bg-secondary",
			ghost: "hover:bg-secondary",
			destructive: "bg-destructive text-primary-foreground hover:bg-destructive/90"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-11 rounded-lg px-5",
			icon: "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset: 6,
		className: cn("z-50 min-w-40 rounded-xl bg-popover p-1 text-popover-foreground shadow-[var(--shadow-border)]", className),
		...props
	}) });
}
function DropdownMenuItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-sm outline-none select-none hover:bg-secondary focus:bg-secondary", className),
		...props
	});
}
function ScrollArea({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
		className: cn("overflow-hidden", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scrollbar, {
			orientation: "vertical",
			className: "flex w-2 touch-none select-none p-0.5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { className: "relative flex-1 rounded-full bg-border" })
		})]
	});
}
var Sheet = Dialog$1;
function SheetContent({ className, children, side = "left", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent$1, {
		className: cn("fixed z-50 flex h-full w-[min(20rem,100vw)] flex-col bg-card text-card-foreground shadow-[var(--shadow-border)]", side === "left" ? "inset-y-0 left-0" : "inset-y-0 right-0", className),
		...props,
		children
	})] });
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 items-center rounded-full border border-border bg-secondary transition-colors duration-150 data-[state=checked]:bg-primary", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-4 translate-x-1 rounded-full bg-foreground transition-transform duration-150 data-[state=checked]:translate-x-5 data-[state=checked]:bg-primary-foreground" })
	});
}
function NavLinks({ onNavigate }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const industry = useAppStore((s) => s.industryFilter);
	const setIndustry = useAppStore((s) => s.setIndustry);
	const items = [
		{
			to: "/",
			label: "Command"
		},
		{
			to: "/catalog",
			label: "Boards"
		},
		{
			to: "/data",
			label: "Excel"
		},
		{
			to: "/fx",
			label: "FX"
		}
	];
	const boards = DASHBOARDS.filter((d) => d.industry === industry).slice(0, 12);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 px-3 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex flex-col gap-1",
				children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					onClick: onNavigate,
					className: cn("rounded-lg px-3 py-2 text-sm transition-colors duration-150", path === item.to ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"),
					children: item.label
				}, item.to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-2 text-[11px] tracking-wide text-muted-foreground uppercase",
				children: "Industry"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setIndustry("all"),
					className: cn("rounded-lg px-3 py-2 text-left text-sm", industry === "all" ? "bg-secondary" : "text-muted-foreground hover:bg-secondary/60"),
					children: "All divisions"
				}), INDUSTRIES.map((ind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setIndustry(ind.id),
					className: cn("rounded-lg px-3 py-2 text-left text-sm", industry === ind.id ? "bg-secondary" : "text-muted-foreground hover:bg-secondary/60"),
					children: ind.label
				}, ind.id))]
			})] }),
			industry !== "all" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-2 text-[11px] tracking-wide text-muted-foreground uppercase",
				children: "Department boards"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col",
				children: boards.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/board/$id",
					params: { id: b.id },
					onClick: onNavigate,
					className: cn("rounded-lg px-3 py-2 text-sm", path === `/board/${b.id}` ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/60"),
					children: b.title.replace(/^[^\s]+ /, "")
				}, b.id))
			})] })
		]
	});
}
function Sidebar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "hidden h-dvh w-64 shrink-0 flex-col border-r border-border bg-card lg:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2.5 px-5 py-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-lg leading-none",
				children: "Meridian"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 text-[11px] text-muted-foreground",
				children: [DASHBOARD_COUNT, " live boards"]
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
			className: "flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {})
		})]
	});
}
function Topbar() {
	const company = useAppStore((s) => s.company);
	const source = useAppStore((s) => s.source);
	const live = useAppStore((s) => s.liveEnabled);
	const setLive = useAppStore((s) => s.setLive);
	const ccy = useAppStore((s) => s.displayCurrency);
	const setCurrency = useAppStore((s) => s.setCurrency);
	const tick = useAppStore((s) => s.tick);
	const last = useAppStore((s) => s.lastReport);
	const countdown = useCountdown();
	const [menu, setMenu] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 flex h-14 items-center gap-2 border-b border-border bg-background/90 px-3 backdrop-blur-sm lg:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: menu,
				onOpenChange: setMenu,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					className: "lg:hidden",
					onClick: () => setMenu(true),
					"aria-label": "Open menu",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 px-5 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg",
						children: "Meridian"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, { onNavigate: () => setMenu(false) })
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate text-sm",
					children: company
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-[11px] text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full bg-up", live && "live-dot") }),
						source === "sample" ? "Sample workbook" : "Uploaded workbook",
						last ? ` · +${last.added}/~${last.updated} last patch` : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "hidden gap-2 md:inline-flex",
				onClick: () => window.dispatchEvent(new KeyboardEvent("keydown", {
					key: "k",
					metaKey: true
				})),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5" }),
					"Jump",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
						className: "rounded bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground",
						children: "⌘K"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					className: "tabular",
					children: ccy
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
				align: "end",
				className: "max-h-80 overflow-y-auto",
				children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					onSelect: () => setCurrency(c.code),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-10 tabular",
						children: c.code
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: c.name
					})]
				}, c.code))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden items-center gap-2 sm:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] text-muted-foreground tabular",
					children: countdown
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: live,
					onCheckedChange: setLive,
					"aria-label": "Live feed"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				onClick: () => tick(),
				"aria-label": "Refresh now",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				asChild: true,
				className: "lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/data",
					"aria-label": "Excel data",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				asChild: true,
				className: "hidden lg:inline-flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/catalog",
					"aria-label": "Board catalog",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				asChild: true,
				className: "hidden lg:inline-flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/data",
					"aria-label": "Data studio",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4" })
				})
			})
		]
	});
}
function AppShell({ children }) {
	(0, import_react.useEffect)(() => {
		hydrateCurrency();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveEngine, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandPalette, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Topbar, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 px-3 py-5 lg:px-6 lg:py-6",
					children
				})]
			})
		]
	});
}
function TooltipProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration: 200,
		skipDelayDuration: 80,
		children
	});
}
var styles_default = "/assets/styles-C45i1kdM.css";
var APP_NAME = "Meridian";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#09090b"
			},
			{
				name: "description",
				content: "Live finance, retail, and operations command center. Excel-driven, multi-currency, 150 department boards."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-DcXbLT6n.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./catalog-BfgQcCtm.mjs");
var Route$3 = createFileRoute("/catalog")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./data-_6Ebb2CO.mjs");
var Route$2 = createFileRoute("/data")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./fx-uG11wJN4.mjs");
var Route$1 = createFileRoute("/fx")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./board._id-Da_TTxTO.mjs");
var Route = createFileRoute("/board/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	CatalogRoute: Route$3.update({
		id: "/catalog",
		path: "/catalog",
		getParentRoute: () => Route$5
	}),
	DataRoute: Route$2.update({
		id: "/data",
		path: "/data",
		getParentRoute: () => Route$5
	}),
	FxRoute: Route$1.update({
		id: "/fx",
		path: "/fx",
		getParentRoute: () => Route$5
	}),
	BoardIdRoute: Route.update({
		id: "/board/$id",
		path: "/board/$id",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { INDUSTRIES as _, useAppStore as a, parseWorkbook as c, DASHBOARDS as d, DASHBOARD_COUNT as f, FX_TO_USD as g, DEPARTMENTS as h, Button as i, workbookToXlsx as l, CURRENCIES as m, Route as n, blankTemplateWorkbook as o, dashboardById as p, Switch as r, downloadArrayBuffer as s, router_exports as t, generateSampleWorkbook as u, cn as v };
