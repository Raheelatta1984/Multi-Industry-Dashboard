import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as INDUSTRIES, a as useAppStore, h as DEPARTMENTS, v as cn } from "./router-CvEkSbUt.mjs";
import { C as vendorBars, S as upcomingRows, _ as opexSeries, a as demandCompare, b as revenueSeries, c as forecastCompare, f as formatNumber, g as licenseRows, h as kpisFor, i as currencyExposure, l as formatDate, n as channelMix, o as departmentShare, p as formatPct, s as expenseStack, t as assetRows, u as formatMoney, v as regionBars, x as skuDemand, y as relativeTime } from "./selectors-MiIHOkmM.mjs";
import { a as SimpleDonut, i as SimpleBar, n as DualArea, o as StackedSpend, r as ForecastLines, t as DemandLines } from "./charts-BJjtjZ3C.mjs";
import { t as Badge } from "./badge-B0bSb0m1.mjs";
import { t as Card } from "./card-iUfGZlHj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/widgets-CwTlNA6j.js
var import_jsx_runtime = require_jsx_runtime();
function Sparkline({ points, className, tone = "neutral" }) {
	if (points.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-7 w-20", className) });
	const min = Math.min(...points);
	const span = Math.max(...points) - min || 1;
	const w = 88;
	const h = 28;
	const p = 2;
	const d = points.map((v, i) => {
		const x = p + i / (points.length - 1) * 84;
		const y = 26 - (v - min) / span * 24;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: w,
		height: h,
		viewBox: `0 0 ${w} ${h}`,
		className: cn("overflow-visible", tone === "up" && "text-up", tone === "down" && "text-down", tone === "neutral" && "text-silver", className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5",
			strokeLinejoin: "round"
		})
	});
}
function heightClass(h) {
	if (h === "lg") return "h-72";
	if (h === "sm") return "h-40";
	return "h-56";
}
function spanClass(span) {
	if (span === 4) return "lg:col-span-4";
	if (span === 5) return "lg:col-span-5";
	if (span === 6) return "lg:col-span-6";
	if (span === 7) return "lg:col-span-7";
	if (span === 8) return "lg:col-span-8";
	return "lg:col-span-12";
}
function formatKpi(kpi, ccy) {
	if (kpi.format === "money") return formatMoney(kpi.value, ccy, { compact: true });
	if (kpi.format === "pct") return formatPct(kpi.value);
	if (kpi.format === "x") return `${kpi.value.toFixed(2)}x`;
	return formatNumber(kpi.value, true);
}
function KpiCard({ kpi, dirty }) {
	const ccy = useAppStore((s) => s.displayCurrency);
	const up = kpi.delta >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: cn("p-4", dirty && "kpi-dirty"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs tracking-wide text-muted-foreground uppercase",
					children: kpi.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 font-display text-3xl leading-none tabular",
					children: formatKpi(kpi, ccy)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mt-2 text-xs tabular", up ? "text-up" : "text-down"),
					children: [formatPct(kpi.delta), " vs prior"]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
				points: kpi.spark,
				tone: up ? "up" : "down"
			})]
		})
	});
}
function Panel({ title, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: cn("flex flex-col", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-between px-4 pt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm text-muted-foreground",
				children: title
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 p-2 pt-1",
			children
		})]
	});
}
function ActivityFeed() {
	const reports = useAppStore((s) => s.reports);
	if (!reports.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-3 py-6 text-sm text-muted-foreground",
		children: "Waiting for the first incremental tick. Unchanged history stays put."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2 px-3 pb-3",
		children: reports.slice(0, 8).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start justify-between gap-3 rounded-lg bg-secondary/50 px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm",
				children: [
					"+",
					r.added,
					" / ~",
					r.updated,
					" / -",
					r.removed
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-muted-foreground",
				children: [
					r.skipped,
					" unchanged · ",
					r.latencyMs,
					"ms · ",
					r.sheetsTouched.join(", ") || "none"
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground tabular",
				children: relativeTime(r.at)
			})]
		}, r.at))
	});
}
function Heatmap() {
	const wb = useAppStore((s) => s.workbook);
	const ccy = useAppStore((s) => s.displayCurrency);
	const rates = new Map(wb.fx.map((r) => [r.currency, r.rateToUsd]));
	const cells = (() => {
		const map = /* @__PURE__ */ new Map();
		for (const row of wb.expenses) {
			if (row.date < "2026-01-01") continue;
			const k = `${row.industry}|${row.department}`;
			map.set(k, { score: (map.get(k)?.score ?? 0) + row.amount });
		}
		const rev = /* @__PURE__ */ new Map();
		for (const row of wb.revenue) {
			if (row.date < "2026-01-01") continue;
			`${row.industry}`;
			rev.set(row.industry, (rev.get(row.industry) ?? 0) + row.amount);
		}
		return {
			map,
			rev,
			rates,
			ccy
		};
	})();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto px-2 pb-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-[720px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[7rem_repeat(12,minmax(0,1fr))] gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
					DEPARTMENTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "truncate px-1 text-center text-[10px] text-muted-foreground",
						children: d.label
					}, d.id)),
					INDUSTRIES.map((ind) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "contents",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate py-1 text-xs text-muted-foreground",
							children: ind.short
						}), DEPARTMENTS.map((d) => {
							const share = (cells.map.get(`${ind.id}|${d.id}`)?.score ?? 0) / ((cells.rev.get(ind.id) ?? 1) / 12 + 1);
							const tone = share > 1.2 ? "bg-down/40" : share > .7 ? "bg-silver/25" : "bg-up/30";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/board/$id",
								params: { id: `${ind.id}-${d.id}` },
								className: cn("block h-8 rounded-md transition-opacity duration-150 hover:opacity-80", tone),
								"aria-label": `${ind.label} ${d.label}`
							}, `${ind.id}-${d.id}`);
						})]
					}, ind.id))
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-4 text-[11px] text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-up/30" }), " lean"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-silver/25" }), " balanced"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-down/40" }), " heavy"]
					})
				]
			})]
		})
	});
}
function WidgetBody({ widget, board }) {
	const wb = useAppStore((s) => s.workbook);
	const ccy = useAppStore((s) => s.displayCurrency);
	const dirtyUntil = useAppStore((s) => s.dirtyUntil);
	const dirty = Date.now() < dirtyUntil;
	const rates = new Map(wb.fx.map((r) => [r.currency, r.rateToUsd]));
	const slice = {
		industry: board.industry,
		department: board.department
	};
	const kpis = kpisFor(wb, slice, ccy, rates);
	if (widget.kind === "kpi" && widget.metric) {
		const kpi = kpis[widget.metric];
		if (!kpi) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
			kpi: {
				...kpi,
				label: widget.title
			},
			dirty
		});
	}
	if (widget.kind === "area") {
		const rev = revenueSeries(wb, slice, ccy, rates);
		const opex = opexSeries(wb, slice, ccy, rates);
		const data = rev.map((r, i) => ({
			period: r.period,
			revenue: r.value,
			opex: opex[i]?.value ?? 0
		}));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: widget.title,
			className: heightClass(widget.height),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DualArea, {
				data,
				aKey: "revenue",
				bKey: "opex",
				aName: "Revenue",
				bName: "Expenditure"
			})
		});
	}
	if (widget.kind === "bar") {
		const data = widget.metric === "licenses" ? vendorBars(wb, slice, ccy, rates) : widget.metric === "demand" ? skuDemand(wb, slice) : widget.metric === "fxExposure" ? currencyExposure(wb, slice, ccy, rates) : widget.metric === "assets" ? assetRows(wb, slice, ccy, rates).slice(0, 8).map((a) => ({
			name: a.category,
			value: a.bookC
		})) : regionBars(wb, slice, ccy, rates);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: widget.title,
			className: heightClass(widget.height),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleBar, {
				data,
				money: widget.metric !== "demand"
			})
		});
	}
	if (widget.kind === "stack") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: widget.title,
		className: heightClass(widget.height),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StackedSpend, { data: expenseStack(wb, slice, ccy, rates) })
	});
	if (widget.kind === "donut") {
		const data = widget.metric === "opex" ? departmentShare(wb, slice, ccy, rates) : widget.metric === "assets" ? assetRows(wb, slice, ccy, rates).reduce((acc, a) => {
			const hit = acc.find((x) => x.name === a.category);
			if (hit) hit.value += a.bookC;
			else acc.push({
				name: a.category,
				value: a.bookC
			});
			return acc;
		}, []) : widget.metric === "licenses" ? [{
			name: "Annual",
			value: wb.licenses.filter((l) => l.cycle === "annual").length
		}, {
			name: "Monthly",
			value: wb.licenses.filter((l) => l.cycle === "monthly").length
		}] : channelMix(wb, slice, ccy, rates);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: widget.title,
			className: heightClass(widget.height),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleDonut, { data })
		});
	}
	if (widget.kind === "forecast") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: widget.title,
		className: heightClass(widget.height),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForecastLines, { data: forecastCompare(wb, slice, ccy, rates) })
	});
	if (widget.kind === "demand") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: widget.title,
		className: heightClass(widget.height),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemandLines, { data: demandCompare(wb, slice) })
	});
	if (widget.kind === "upcoming") {
		const rows = upcomingRows(wb, slice, ccy, rates);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: widget.title,
			className: heightClass(widget.height),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-full overflow-auto px-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Due"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "font-medium",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "font-medium",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right font-medium",
								children: "Amount"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 tabular text-muted-foreground",
								children: formatDate(r.dueDate)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.description }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: r.type
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular",
								children: formatMoney(r.converted, ccy, { compact: true })
							})
						]
					}, r.id)) })]
				})
			})
		});
	}
	if (widget.kind === "licenses") {
		const rows = licenseRows(wb, slice, ccy, rates);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: widget.title,
			className: heightClass(widget.height),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-full overflow-auto px-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "License"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "font-medium",
								children: "Seats"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "font-medium",
								children: "End"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right font-medium",
								children: "Annual"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2",
								children: [r.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: r.vendor
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "tabular",
								children: r.seats
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "tabular text-muted-foreground",
								children: formatDate(r.end)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular",
								children: formatMoney(r.annual, ccy, { compact: true })
							})
						]
					}, r.id)) })]
				})
			})
		});
	}
	if (widget.kind === "assets") {
		const rows = assetRows(wb, slice, ccy, rates);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: widget.title,
			className: heightClass(widget.height),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-full overflow-auto px-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Asset"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "font-medium",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right font-medium",
								children: "Cost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right font-medium",
								children: "Book"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2",
								children: [r.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: r.category
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: r.status === "active" ? "up" : r.status === "idle" ? "warn" : "outline",
								children: r.status
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular",
								children: formatMoney(r.costC, ccy, { compact: true })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular",
								children: formatMoney(r.bookC, ccy, { compact: true })
							})
						]
					}, r.id)) })]
				})
			})
		});
	}
	if (widget.kind === "fx") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: widget.title,
		className: heightClass(widget.height),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-h-full overflow-auto px-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-left text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "CCY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right font-medium",
							children: "USD per unit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right font-medium",
							children: "As of"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: wb.fx.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							children: r.currency
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right tabular",
							children: r.rateToUsd.toPrecision(4)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right tabular text-muted-foreground",
							children: formatDate(r.asOf)
						})
					]
				}, r.id)) })]
			})
		})
	});
	if (widget.kind === "heatmap") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: widget.title,
		className: heightClass(widget.height),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heatmap, {})
	});
	if (widget.kind === "activity") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: widget.title,
		className: heightClass(widget.height),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActivityFeed, {})
	});
	return null;
}
function DashboardCanvas({ board }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-1 gap-3 lg:grid-cols-12",
		children: board.widgets.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("col-span-1", spanClass(w.span)),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WidgetBody, {
				widget: w,
				board
			})
		}, w.id))
	});
}
//#endregion
export { DashboardCanvas as t };
