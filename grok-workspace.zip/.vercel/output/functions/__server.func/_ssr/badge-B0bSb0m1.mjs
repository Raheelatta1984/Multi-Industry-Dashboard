import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as cn } from "./router-CvEkSbUt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-B0bSb0m1.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-secondary text-secondary-foreground",
		silver: "bg-silver/15 text-silver",
		up: "bg-up/15 text-up",
		down: "bg-down/15 text-down",
		warn: "bg-warn/15 text-warn",
		outline: "border border-border text-muted-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
