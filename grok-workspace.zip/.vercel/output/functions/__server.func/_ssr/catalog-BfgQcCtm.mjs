import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as INDUSTRIES, d as DASHBOARDS, f as DASHBOARD_COUNT, h as DEPARTMENTS, v as cn } from "./router-CvEkSbUt.mjs";
import { t as Badge } from "./badge-B0bSb0m1.mjs";
import { t as Card } from "./card-iUfGZlHj.mjs";
import { t as Input } from "./input-DJTOUk9i.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-BfgQcCtm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CatalogPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [industry, setIndustry] = (0, import_react.useState)("all");
	const [dept, setDept] = (0, import_react.useState)("all");
	const list = (0, import_react.useMemo)(() => {
		return DASHBOARDS.filter((d) => {
			if (industry !== "all" && d.industry !== industry && d.industry !== "all") return false;
			if (dept !== "all" && d.department !== dept && d.department !== "group") return false;
			if (!q.trim()) return true;
			const s = q.toLowerCase();
			return `${d.title} ${d.eyebrow} ${d.description}`.toLowerCase().includes(s);
		});
	}, [
		q,
		industry,
		dept
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-7xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.16em] text-silver uppercase",
					children: "Catalog"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-1 font-display text-3xl lg:text-4xl",
					children: [DASHBOARD_COUNT, " department boards"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Twelve industries times twelve departments, plus group command views. Same Excel contract, different slice."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Filter boards",
					className: "lg:max-w-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-wrap gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setIndustry("all"),
						className: cn("rounded-full px-3 py-1.5 text-xs", industry === "all" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: "All industries"
					}), INDUSTRIES.map((ind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setIndustry(ind.id),
						className: cn("rounded-full px-3 py-1.5 text-xs", industry === ind.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: ind.short
					}, ind.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setDept("all"),
					className: cn("rounded-full px-3 py-1.5 text-xs", dept === "all" ? "bg-silver/20 text-silver" : "bg-secondary text-muted-foreground"),
					children: "All departments"
				}), DEPARTMENTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setDept(d.id),
					className: cn("rounded-full px-3 py-1.5 text-xs", dept === d.id ? "bg-silver/20 text-silver" : "bg-secondary text-muted-foreground"),
					children: d.label
				}, d.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [list.length, " boards"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: list.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/board/$id",
					params: { id: d.id },
					className: "group",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "h-full p-4 transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: d.eyebrow
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-muted-foreground",
									children: [d.widgets.length, " widgets"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-xl leading-snug group-hover:text-silver",
								children: d.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: d.description
							})
						]
					})
				}, d.id))
			})
		]
	});
}
//#endregion
export { CatalogPage as component };
