import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as DASHBOARDS, i as Button, n as Route, p as dashboardById } from "./router-CvEkSbUt.mjs";
import { t as Badge } from "./badge-B0bSb0m1.mjs";
import { t as DashboardCanvas } from "./widgets-CwTlNA6j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/board._id-Da_TTxTO.js
var import_jsx_runtime = require_jsx_runtime();
function BoardPage() {
	const { id } = Route.useParams();
	const board = dashboardById(id) ?? DASHBOARDS[0];
	const related = DASHBOARDS.filter((d) => d.industry === board.industry && d.id !== board.id).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-7xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.16em] text-silver uppercase",
						children: board.eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl lg:text-4xl",
						children: board.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-2xl text-sm text-muted-foreground",
						children: board.description
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: board.industry
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "silver",
						children: board.department
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardCanvas, { board }),
			related.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: related.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/board/$id",
						params: { id: d.id },
						children: d.title
					})
				}, d.id))
			})
		]
	});
}
//#endregion
export { BoardPage as component };
