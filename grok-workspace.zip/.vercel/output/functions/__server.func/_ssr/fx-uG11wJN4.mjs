import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useAppStore, i as Button, l as workbookToXlsx, m as CURRENCIES, s as downloadArrayBuffer } from "./router-CvEkSbUt.mjs";
import { h as kpisFor, i as currencyExposure, m as fxMap, r as convertAmount, u as formatMoney } from "./selectors-MiIHOkmM.mjs";
import { i as SimpleBar } from "./charts-BJjtjZ3C.mjs";
import { t as Card } from "./card-iUfGZlHj.mjs";
import { t as Input } from "./input-DJTOUk9i.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fx-uG11wJN4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FxPage() {
	const wb = useAppStore((s) => s.workbook);
	const display = useAppStore((s) => s.displayCurrency);
	const setCurrency = useAppStore((s) => s.setCurrency);
	const rates = fxMap(wb.fx);
	const [amount, setAmount] = (0, import_react.useState)("1000000");
	const [from, setFrom] = (0, import_react.useState)("EUR");
	const n = Number(amount) || 0;
	const converted = convertAmount(n, from, display, rates);
	const exposure = currencyExposure(wb, {
		industry: "all",
		department: "group"
	}, display, rates);
	const kpis = kpisFor(wb, {
		industry: "all",
		department: "group"
	}, display, rates);
	const table = (0, import_react.useMemo)(() => {
		return wb.fx.map((row) => ({
			...row,
			oneDisplay: convertAmount(1, row.currency, display, rates)
		}));
	}, [
		wb.fx,
		display,
		rates
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-5xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.16em] text-silver uppercase",
					children: "Treasury"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl lg:text-4xl",
					children: "Multi-currency conversion"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Every board reads source amounts in native currency, then converts with the FX sheet. Export a converted workbook for Excel without mutating stored history."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground uppercase",
							children: "Display"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 font-display text-3xl",
							children: display
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground uppercase",
							children: "Converted revenue YTD"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 font-display text-3xl tabular",
							children: formatMoney(kpis.revenue.value, display, { compact: true })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground uppercase",
							children: "FX exposure"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 font-display text-3xl tabular",
							children: formatMoney(kpis.fxExposure.value, display, { compact: true })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Converter"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: ["Amount", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "mt-1",
									value: amount,
									onChange: (e) => setAmount(e.target.value),
									inputMode: "decimal"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: ["From", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "mt-1 flex h-10 w-full rounded-md border border-input bg-card px-3 text-sm",
									value: from,
									onChange: (e) => setFrom(e.target.value),
									children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: c.code,
										children: [
											c.code,
											" · ",
											c.name
										]
									}, c.code))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: ["To", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "mt-1 flex h-10 w-full rounded-md border border-input bg-card px-3 text-sm",
									value: display,
									onChange: (e) => setCurrency(e.target.value),
									children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: c.code,
										children: [
											c.code,
											" · ",
											c.name
										]
									}, c.code))
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 font-display text-3xl tabular",
						children: formatMoney(converted, display)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "h-72 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "px-2 text-sm text-muted-foreground",
					children: "Revenue exposure by currency"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-60",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleBar, { data: exposure })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Rate card"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => downloadArrayBuffer(workbookToXlsx(wb, {
							currency: display,
							rates
						}), `meridian-converted-${display.toLowerCase()}.xlsx`),
						children: "Export converted Excel"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "mt-4 w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Currency"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right font-medium",
								children: "USD per unit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
								className: "text-right font-medium",
								children: ["1 unit in ", display]
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: table.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: r.currency
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular",
								children: r.rateToUsd.toPrecision(4)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular",
								children: r.oneDisplay.toPrecision(4)
							})
						]
					}, r.id)) })]
				})]
			})
		]
	});
}
//#endregion
export { FxPage as component };
